import 'package:flutter_test/flutter_test.dart';
import 'package:bloc_test/bloc_test.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';

import 'package:semantic_file_finder/services/ai/embedding_service.dart';
import 'package:semantic_file_finder/features/duplicate/bloc/duplicate_bloc.dart';
import 'package:semantic_file_finder/data/repositories/ai_repository.dart';
import 'package:semantic_file_finder/data/models/scanned_file.dart';

@GenerateMocks([AiRepository])
import 'app_test.mocks.dart';

void main() {
  // ──────────────────────────────────────────────────────
  // EmbeddingService Unit Tests
  // ──────────────────────────────────────────────────────
  group('EmbeddingService', () {
    late EmbeddingService service;

    setUp(() {
      service = EmbeddingService();
      // No model file in test — will use TF-IDF fallback automatically
    });

    test('embed returns 768-dim vector', () async {
      await service.initialize();
      final vec = await service.embed('Hello world test document');
      expect(vec.length, equals(768));
    });

    test('embed returns normalized vector (L2 norm ≈ 1)', () async {
      await service.initialize();
      final vec = await service.embed('Test sentence for normalization');
      final norm =
          vec.fold(0.0, (sum, v) => sum + v * v);
      expect(norm, closeTo(1.0, 0.001));
    });

    test('identical texts have similarity ≈ 1.0', () async {
      await service.initialize();
      final text = 'The quick brown fox jumps over the lazy dog';
      final v1 = await service.embed(text);
      final v2 = await service.embed(text);
      final sim = service.cosineSimilarity(v1, v2);
      expect(sim, closeTo(1.0, 0.001));
    });

    test('completely different texts have lower similarity', () async {
      await service.initialize();
      final v1 = await service.embed('Annual financial report Q4 2025 revenue');
      final v2 = await service.embed('Recipe: boil pasta add tomato sauce');
      final sim = service.cosineSimilarity(v1, v2);
      // Different topics — similarity should be low
      expect(sim, lessThan(0.8));
    });

    test('similar texts have higher similarity than unrelated', () async {
      await service.initialize();
      final original = await service.embed('Sales report for Q3 showing growth');
      final similar = await service.embed('Q3 sales analysis demonstrating increase');
      final unrelated = await service.embed('How to cook spaghetti carbonara');

      final simSimilar = service.cosineSimilarity(original, similar);
      final simUnrelated = service.cosineSimilarity(original, unrelated);

      expect(simSimilar, greaterThan(simUnrelated));
    });

    test('findDuplicates returns empty for dissimilar texts', () async {
      await service.initialize();
      final docs = [
        DocumentEmbedding(
          fileId: '1',
          fileName: 'cooking.pdf',
          filePath: '/cooking.pdf',
          vector: await service.embed('Pasta recipe with tomato and basil'),
          scannedAt: DateTime.now(),
        ),
        DocumentEmbedding(
          fileId: '2',
          fileName: 'finance.pdf',
          filePath: '/finance.pdf',
          vector: await service.embed('Q4 revenue analysis and budget forecast'),
          scannedAt: DateTime.now(),
        ),
      ];

      final pairs = await service.findDuplicates(docs, threshold: 0.87);
      expect(pairs, isEmpty);
    });

    test('findDuplicates detects near-duplicate texts', () async {
      await service.initialize();
      final original = 'Annual sales report showing Q3 revenue increase of 15 percent';
      final rewritten = 'Yearly sales document indicating Q3 income grew by 15 percent';

      final docs = [
        DocumentEmbedding(
          fileId: '1',
          fileName: 'report_v1.pdf',
          filePath: '/report_v1.pdf',
          vector: await service.embed(original),
          scannedAt: DateTime.now(),
        ),
        DocumentEmbedding(
          fileId: '2',
          fileName: 'report_v2.pdf',
          filePath: '/report_v2.pdf',
          vector: await service.embed(rewritten),
          scannedAt: DateTime.now(),
        ),
      ];

      // With TF-IDF fallback, the threshold needs to be lower for test accuracy
      final pairs = await service.findDuplicates(docs, threshold: 0.70);
      // These are semantically similar — should be detected
      expect(pairs, isNotEmpty);
    });
  });

  // ──────────────────────────────────────────────────────
  // DuplicateBloc Tests
  // ──────────────────────────────────────────────────────
  group('DuplicateBloc', () {
    late MockAiRepository mockRepo;
    late DuplicateBloc bloc;

    final dummyFiles = [
      ScannedFile(
        id: 'a1',
        name: 'doc1.pdf',
        path: '/doc1.pdf',
        extension: 'pdf',
        sizeBytes: 1024,
        modifiedAt: DateTime.now(),
        scannedAt: DateTime.now(),
        textContent: 'Revenue report Q3 annual financial results',
        source: FileSource.localStorage,
      ),
      ScannedFile(
        id: 'a2',
        name: 'doc2.pdf',
        path: '/doc2.pdf',
        extension: 'pdf',
        sizeBytes: 1024,
        modifiedAt: DateTime.now(),
        scannedAt: DateTime.now(),
        textContent: 'Q3 revenue annual financial report results',
        source: FileSource.localStorage,
      ),
    ];

    setUp(() {
      mockRepo = MockAiRepository();
    });

    tearDown(() => bloc.close());

    blocTest<DuplicateBloc, DuplicateState>(
      'emits DuplicateNoneFound for empty file list',
      build: () {
        bloc = DuplicateBloc(aiRepo: mockRepo);
        return bloc;
      },
      act: (b) =>
          b.add(const AnalyzeDuplicatesEvent(files: [])),
      expect: () => [isA<DuplicateNoneFound>()],
    );

    blocTest<DuplicateBloc, DuplicateState>(
      'emits DuplicateEmbedding then result state',
      build: () {
        when(mockRepo.generateEmbedding(any)).thenAnswer((_) async =>
            DocumentEmbedding(
              fileId: 'test',
              fileName: 'test.pdf',
              filePath: '/test.pdf',
              vector: List.filled(768, 0.1),
              scannedAt: DateTime.now(),
            ));
        when(mockRepo.findDuplicates(any, threshold: anyNamed('threshold')))
            .thenAnswer((_) async => []);
        bloc = DuplicateBloc(aiRepo: mockRepo);
        return bloc;
      },
      act: (b) => b.add(AnalyzeDuplicatesEvent(files: dummyFiles)),
      expect: () => [
        isA<DuplicateEmbedding>(),
        isA<DuplicateEmbedding>(),
        isA<DuplicateAnalyzing>(),
        isA<DuplicateNoneFound>(),
      ],
    );
  });

  // ──────────────────────────────────────────────────────
  // DuplicatePair Category Tests
  // ──────────────────────────────────────────────────────
  group('DuplicatePair category', () {
    DocumentEmbedding dummyDoc(String id) => DocumentEmbedding(
          fileId: id,
          fileName: '$id.pdf',
          filePath: '/$id.pdf',
          vector: List.filled(768, 0.0),
          scannedAt: DateTime.now(),
        );

    test('similarity 0.99 = exactCopy', () {
      final pair = DuplicatePair(
          docA: dummyDoc('a'), docB: dummyDoc('b'), similarity: 0.99);
      expect(pair.category, DuplicateCategory.exactCopy);
    });

    test('similarity 0.92 = nearDuplicate', () {
      final pair = DuplicatePair(
          docA: dummyDoc('a'), docB: dummyDoc('b'), similarity: 0.92);
      expect(pair.category, DuplicateCategory.nearDuplicate);
    });

    test('similarity 0.86 = similarContent', () {
      final pair = DuplicatePair(
          docA: dummyDoc('a'), docB: dummyDoc('b'), similarity: 0.86);
      expect(pair.category, DuplicateCategory.similarContent);
    });

    test('similarityPercent formats correctly', () {
      final pair = DuplicatePair(
          docA: dummyDoc('a'), docB: dummyDoc('b'), similarity: 0.876);
      expect(pair.similarityPercent, equals('87.6%'));
    });
  });
}
