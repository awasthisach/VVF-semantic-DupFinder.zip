import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:mockito/mockito.dart';
import 'package:mockito/annotations.dart';

import 'package:semantic_file_finder/features/home/home_screen.dart';
import 'package:semantic_file_finder/features/scan/bloc/scan_bloc.dart';
import 'package:semantic_file_finder/features/duplicate/bloc/duplicate_bloc.dart';
import 'package:semantic_file_finder/features/sort/bloc/sort_bloc.dart';
import 'package:semantic_file_finder/data/repositories/file_repository.dart';
import 'package:semantic_file_finder/data/repositories/ai_repository.dart';
import 'package:semantic_file_finder/data/repositories/drive_repository.dart';

@GenerateMocks([FileRepository, AiRepository, DriveRepository])
import 'widget_test.mocks.dart';

void main() {
  late MockFileRepository mockFileRepo;
  late MockAiRepository mockAiRepo;
  late MockDriveRepository mockDriveRepo;

  setUp(() {
    mockFileRepo = MockFileRepository();
    mockAiRepo = MockAiRepository();
    mockDriveRepo = MockDriveRepository();
    when(mockDriveRepo.isSignedIn).thenReturn(false);
    when(mockDriveRepo.hasDriveAccess).thenReturn(false);
    when(mockDriveRepo.userEmail).thenReturn(null);
  });

  Widget buildApp() => MaterialApp(
        home: MultiBlocProvider(
          providers: [
            BlocProvider<ScanBloc>(
              create: (_) => ScanBloc(
                fileRepo: mockFileRepo,
                driveRepo: mockDriveRepo,
                parserService: null as dynamic,
              ),
            ),
            BlocProvider<DuplicateBloc>(
              create: (_) => DuplicateBloc(aiRepo: mockAiRepo),
            ),
            BlocProvider<SortBloc>(
              create: (_) => SortBloc(fileRepo: mockFileRepo),
            ),
          ],
          child: const HomeScreen(),
        ),
      );

  testWidgets('HomeScreen renders scan source tiles', (tester) async {
    await tester.pumpWidget(buildApp());
    await tester.pump();

    expect(find.text('Scan sources'), findsOneWidget);
    expect(find.text('Local files'), findsOneWidget);
    expect(find.text('Google Drive'), findsOneWidget);
    expect(find.text('Pick files'), findsOneWidget);
  });

  testWidgets('Tapping Local files triggers ScanLocalStorageEvent',
      (tester) async {
    await tester.pumpWidget(buildApp());
    await tester.pump();

    // Tap the local files tile
    await tester.tap(find.text('Local files'));
    await tester.pump();
    // No crash = pass (actual scan needs real file system)
  });

  testWidgets('Settings icon is present in AppBar', (tester) async {
    await tester.pumpWidget(buildApp());
    expect(find.byIcon(Icons.settings_outlined), findsOneWidget);
  });
}
