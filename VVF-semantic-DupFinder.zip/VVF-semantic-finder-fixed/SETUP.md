# SETUP GUIDE — Semantic File Finder

Yeh guide aapko zero se working Android app tak le jaayega.

---

## Step 1 — Flutter SDK Install

Agar Flutter abhi installed nahi hai:
```bash
# Download Flutter SDK
https://docs.flutter.dev/get-started/install/linux

# Path add karein (~/.bashrc mein)
export PATH="$PATH:/home/yourname/flutter/bin"

# Verify
flutter doctor
```

---

## Step 2 — Project Setup

```bash
# Project folder mein jaayein
cd semantic_file_finder

# Dependencies install karein
flutter pub get

# Check karein sab theek hai
flutter analyze
```

---

## Step 3 — Google Cloud Console Setup

1. **https://console.cloud.google.com** pe jaayein
2. **New Project** banayein → naam: `SemanticFileFinder`
3. Left menu → **APIs & Services → Library**
4. Search: `Google Drive API` → **Enable** karein
5. **Credentials → Create Credentials → OAuth 2.0 Client ID**
   - Application type: **Android**
   - Package name: `com.yourcompany.semantic_file_finder`
   - SHA-1 fingerprint (debug ke liye):
     ```bash
     keytool -list -v \
       -keystore ~/.android/debug.keystore \
       -alias androiddebugkey \
       -storepass android \
       -keypass android
     ```
   - SHA1 copy karein aur paste karein

---

## Step 4 — Firebase Setup (google-services.json)

1. **https://console.firebase.google.com** pe jaayein
2. **Add Project** → same Google Cloud project select karein
3. **Android app add karein**:
   - Package name: `com.yourcompany.semantic_file_finder`
   - App nickname: `Semantic File Finder`
4. **google-services.json download** karein
5. File yahan rakhen:
   ```
   android/app/google-services.json
   ```
   (Placeholder file replace karein)

---

## Step 5 — EmbeddingGemma Model Download

**Option A: Google AI Edge (Recommended)**
```
URL: https://ai.google.dev/edge/mediapipe/solutions/text/text_embedder
Model: EmbeddingGemma 300M (TFLite format)
File: embedding_gemma_300m.tflite
Location: assets/models/embedding_gemma_300m.tflite
```

**Option B: Dev mode (bina model ke)**
- Model file rakhna zaroori nahi testing ke liye
- App automatically TF-IDF fallback use karega
- Similarity results accurate nahi honge production jaisi

---

## Step 6 — Package Name Change (Optional)

Agar aap apna package name use karna chahte hain:

```bash
# android/app/build.gradle mein
applicationId "com.YOURCOMPANY.semantic_file_finder"

# android/app/src/main/AndroidManifest.xml mein
package="com.YOURCOMPANY.semantic_file_finder"

# android/app/src/main/kotlin/... folder rename karein
# MainActivity.kt mein package line update karein
```

---

## Step 7 — Build & Run

```bash
# Connected Android device ya emulator pe run karein
flutter run

# Release APK banayein
flutter build apk --release

# App Bundle (Play Store ke liye)
flutter build appbundle --release
```

---

## Step 8 — Tests Run Karein

```bash
# Mockito mocks generate karein
flutter pub run build_runner build

# Tests chalayein
flutter test

# Coverage
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html
```

---

## Common Errors & Fix

| Error | Fix |
|-------|-----|
| `Permission denied` | Android 13+ pe granular permissions ensure karein |
| `google-services.json not found` | Step 4 dobara karein |
| `TFLite model not found` | Step 5 dobara karein ya fallback mode use karein |
| `OAuth redirect failed` | SHA-1 fingerprint Google Console mein match kare |
| `Drive API 403` | Google Cloud Console mein Drive API enable karein |

---

## App Flow (User Journey)

```
App open
  ↓
Home Screen
  ├── "Local files" button → Storage permission → Scan phone
  ├── "Google Drive" → Google Sign-In → OAuth → Drive scan
  └── "Pick files" → File picker → Selected files scan
  ↓
Scan progress (file by file)
  ↓
Auto: EmbeddingGemma generates vectors (on-device)
  ↓
Cosine similarity matrix compute
  ↓
Home: Stats bar shows duplicates found + space saveable
  ├── "View duplicates" → DuplicateResultsScreen
  │     ├── Groups with similarity %
  │     ├── Swipe to delete duplicates
  │     └── Threshold slider (80%–99%)
  └── "Browse & sort" → SortScreen
        ├── Filter by extension
        ├── Sort by date/name/size/type
        └── Search by filename
```

---

## Architecture Quick Reference

```
lib/
├── main.dart                  ← Entry point, BLoC providers
├── core/
│   ├── di/injection.dart      ← GetIt service locator
│   └── theme/app_theme.dart   ← Material 3 theme
├── features/
│   ├── home/                  ← Main screen
│   ├── scan/bloc/             ← File scanning state
│   ├── duplicate/bloc/        ← AI duplicate detection
│   ├── sort/bloc/             ← File sorting/filtering
│   └── settings/              ← App settings
├── services/
│   ├── ai/embedding_service.dart     ← EmbeddingGemma 3
│   ├── drive/google_drive_service.dart ← Drive API v3
│   └── files/
│       ├── file_scanner_service.dart ← Device scan
│       └── doc_parser_service.dart   ← PDF/DOCX/OCR
└── data/
    ├── models/scanned_file.dart
    └── repositories/
        ├── file_repository.dart
        ├── ai_repository.dart
        └── drive_repository.dart
```
