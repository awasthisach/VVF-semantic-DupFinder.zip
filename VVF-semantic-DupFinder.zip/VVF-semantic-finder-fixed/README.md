# Semantic File Finder — Flutter Project

AI-Driven Semantic Duplicate File Finder & Sorter  
On-device EmbeddingGemma 3 · Google Drive · Local Storage · PDF/DOCX/Images

---

## Project Structure

```
lib/
├── main.dart                          # Entry point
├── core/
│   ├── di/injection.dart             # GetIt dependency injection
│   └── theme/app_theme.dart          # Light/dark theme
│
├── features/
│   ├── home/home_screen.dart         # Main screen (scan sources)
│   ├── scan/
│   │   ├── bloc/scan_bloc.dart       # File scanning state management
│   │   └── widgets/                  # Progress cards
│   ├── duplicate/
│   │   ├── bloc/duplicate_bloc.dart  # AI duplicate analysis
│   │   └── screens/                  # Results UI
│   └── sort/
│       └── bloc/sort_bloc.dart       # File sorting logic
│
├── services/
│   ├── ai/embedding_service.dart     # EmbeddingGemma 3 (on-device)
│   ├── drive/google_drive_service.dart  # Google Drive API v3
│   └── files/
│       ├── file_scanner_service.dart # Local file discovery
│       └── doc_parser_service.dart   # PDF/DOCX/OCR text extraction
│
└── data/
    ├── models/scanned_file.dart      # Core data model
    └── repositories/
        ├── file_repository.dart      # Local file repo
        ├── ai_repository.dart        # AI/embedding repo
        └── drive_repository.dart     # Drive repo
```

---

## Setup Steps (Step-by-step)

### 1. Flutter & Dependencies
```bash
flutter pub get
```

### 2. EmbeddingGemma Model
```
assets/models/ folder mein model rakhen:
- embedding_gemma_300m.tflite  (Google AI Edge se download karein)

Download: https://ai.google.dev/edge/mediapipe/solutions/text/text_embedder
```

### 3. Google OAuth Setup
```
1. Google Cloud Console → New Project
2. APIs & Services → Enable "Google Drive API"
3. Credentials → OAuth 2.0 Client ID → Android
4. Package name: com.yourcompany.semantic_file_finder
5. SHA-1 fingerprint: keytool -list -v -keystore ~/.android/debug.keystore
6. google-services.json → android/app/ mein rakhen
```

### 4. Android Permissions (AndroidManifest.xml)
```xml
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

---

## AI Architecture

```
Text → EmbeddingGemma (300M) → 768-dim vector → Cosine Similarity → Duplicate pairs
                                      ↓
                             On-device FAISS index
                             (no internet needed)
```

**Similarity Thresholds:**
| Range   | Category         | Example                        |
|---------|-----------------|-------------------------------|
| 0.98–1.0 | Exact copy      | Same file, different location  |
| 0.90–0.97 | Near duplicate  | Minor edits, reformatting     |
| 0.85–0.89 | Similar content | Rewritten / different draft   |

**Default threshold: 0.87** (configurable in Settings screen)

---

## TODO (Next Steps)

- [ ] `SortBloc` complete karna (date, size, type, semantic sorting)
- [ ] `DuplicateResultsScreen` UI banana (swipe to delete)
- [ ] ML Kit text recognition integrate karna (image OCR)
- [ ] Isar database se vector caching (re-scan avoid karne ke liye)
- [ ] Threshold slider UI (0.80–0.99 configurable)
- [ ] Google Drive folder picker UI
- [ ] TestSprite / QA Wolf se automated testing
- [ ] Play Store release (AAB build)

---

## Tech Stack

| Layer         | Technology                    |
|--------------|-------------------------------|
| Framework    | Flutter 3.19+ (Dart)         |
| State        | flutter_bloc + equatable      |
| DI           | get_it                        |
| AI Model     | EmbeddingGemma 3 (300M)      |
| ML Runtime   | tflite_flutter + NNAPI       |
| Drive API    | googleapis + google_sign_in   |
| PDF Parse    | syncfusion_flutter_pdf        |
| DOCX Parse   | docx_to_text                  |
| Vector Store | Isar (on-device)              |
| UI           | flutter_animate + flex_color  |
