package com.yourcompany.semantic_file_finder

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
