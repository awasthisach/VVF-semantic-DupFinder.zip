import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter/material.dart';
import 'package:semantic_file_finder/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('App launch integration test', () {
    testWidgets('App starts and shows either onboarding or home',
        (tester) async {
      app.main();
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Should show either onboarding or home screen title
      final hasOnboarding = find.text('Get Started').evaluate().isNotEmpty;
      final hasHome =
          find.text('Semantic File Finder').evaluate().isNotEmpty;

      expect(hasOnboarding || hasHome, isTrue);
    });

    testWidgets('Settings screen opens from home', (tester) async {
      app.main();
      await tester.pumpAndSettle(const Duration(seconds: 3));

      // Skip onboarding if shown
      final skipBtn = find.text('Skip');
      if (skipBtn.evaluate().isNotEmpty) {
        await tester.tap(skipBtn);
        await tester.pumpAndSettle();
      }

      // Tap settings icon
      await tester.tap(find.byIcon(Icons.settings_outlined));
      await tester.pumpAndSettle();

      expect(find.text('Settings'), findsOneWidget);
      expect(find.text('AI Engine'), findsOneWidget);
    });
  });
}
