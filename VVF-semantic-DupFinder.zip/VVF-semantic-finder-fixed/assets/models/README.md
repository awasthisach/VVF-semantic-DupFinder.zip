## TFLite Model Files

Yahan EmbeddingGemma 3 model file rakhein:

1. Google AI Edge se download karein:
   https://ai.google.dev/edge/mediapipe/solutions/text/text_embedder

2. File ka naam: `embedding_gemma_300m.tflite`

3. Isi folder mein rakhen:
   `assets/models/embedding_gemma_300m.tflite`

Dev/testing ke liye bina model ke bhi app chalega —
EmbeddingService automatically TF-IDF fallback use karega.
