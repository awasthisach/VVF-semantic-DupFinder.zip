import 'package:equatable/equatable.dart';

enum FileSource { localStorage, googleDrive, selected }

class ScannedFile extends Equatable {
  final String id;           // MD5 hash for local, Drive ID for Drive files
  final String name;
  final String path;
  final String extension;
  final int sizeBytes;
  final DateTime modifiedAt;
  final DateTime scannedAt;
  final String? textContent; // Extracted plain text (null if parse failed)
  final FileSource source;

  const ScannedFile({
    required this.id,
    required this.name,
    required this.path,
    required this.extension,
    required this.sizeBytes,
    required this.modifiedAt,
    required this.scannedAt,
    this.textContent,
    required this.source,
  });

  bool get hasText => textContent != null && textContent!.isNotEmpty;

  String get sizeFormatted {
    if (sizeBytes > 1024 * 1024) {
      return '${(sizeBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    } else if (sizeBytes > 1024) {
      return '${(sizeBytes / 1024).toStringAsFixed(0)} KB';
    }
    return '$sizeBytes B';
  }

  String get iconAsset {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return 'assets/icons/pdf.svg';
      case 'docx':
      case 'doc':
        return 'assets/icons/docx.svg';
      case 'txt':
      case 'md':
        return 'assets/icons/txt.svg';
      case 'jpg':
      case 'jpeg':
      case 'png':
        return 'assets/icons/image.svg';
      default:
        return 'assets/icons/file.svg';
    }
  }

  @override
  List<Object?> get props => [id, path, scannedAt];
}
