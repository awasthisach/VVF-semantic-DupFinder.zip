import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:logger/logger.dart';

import '../models/scanned_file.dart';
import '../../services/files/file_scanner_service.dart';

class FileRepository {
  final FileScannerService scanner;
  final Logger _log = Logger();

  FileRepository({required this.scanner});

  /// Requests storage permission then returns all matching file paths.
  Future<List<String>> discoverFiles({
    List<String> extensions = const ['pdf', 'docx', 'doc', 'txt'],
  }) async {
    final granted = await _requestPermission();
    if (!granted) throw Exception('Storage permission denied');
    return scanner.scanDevice(allowedExtensions: extensions);
  }

  /// Deletes a file permanently from local storage.
  Future<bool> deleteFile(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        _log.i('Deleted: $filePath');
        return true;
      }
      return false;
    } catch (e) {
      _log.e('Delete failed: $e');
      return false;
    }
  }

  Future<bool> _requestPermission() async {
    if (Platform.isAndroid) {
      // Request storage permission for document access
      final storage = await Permission.storage.request();
      if (storage.isGranted) {
        _log.i('Storage permission granted');
        return true;
      }
      
      // Fallback: Try media permissions
      final photos = await Permission.photos.request();
      final videos = await Permission.videos.request();
      final audio = await Permission.audio.request();
      
      final granted = photos.isGranted || videos.isGranted || audio.isGranted;
      if (granted) {
        _log.i('Media permission granted as fallback');
      } else {
        _log.w('Storage permission denied');
      }
      return granted;
    }
    return true;
  }
}
