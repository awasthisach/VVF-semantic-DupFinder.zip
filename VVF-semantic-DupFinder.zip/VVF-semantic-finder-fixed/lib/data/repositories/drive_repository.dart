import 'package:logger/logger.dart';

import '../models/scanned_file.dart';
import '../../services/drive/google_drive_service.dart';
import '../../services/files/doc_parser_service.dart';

class DriveRepository {
  final GoogleDriveService driveService;
  final DocParserService parserService; // ← injected, not self-created
  final Logger _log = Logger();

  DriveRepository({
    required this.driveService,
    required this.parserService,
  });

  Future<bool> ensureDriveAccess() async {
    if (driveService.hasDriveAccess) return true;
    if (!driveService.isSignedIn) {
      final account = await driveService.signIn();
      if (account == null) return false;
    }
    return driveService.requestDriveAccess();
  }

  Future<List<DriveFileInfo>> listDocuments({String? folderId}) {
    return driveService.listDocuments(folderId: folderId);
  }

  Future<ScannedFile?> downloadAndParse(DriveFileInfo file) async {
    try {
      if (file.isGoogleDoc) {
        final text = await driveService.exportAsText(file.id, file.mimeType);
        if (text == null || text.isEmpty) return null;
        return parserService.parseFromText(
          text: text,
          fileName: file.name,
          fileId: file.id,
          sizeBytes: file.sizeBytes ?? 0,
          modifiedAt: file.modifiedTime,
        );
      }
      final bytes = await driveService.downloadBinary(file.id);
      if (bytes == null) return null;
      return parserService.parseFromBytes(
        bytes: bytes,
        fileName: file.name,
        fileId: file.id,
        mimeType: file.mimeType,
        sizeBytes: file.sizeBytes ?? 0,
        modifiedAt: file.modifiedTime,
      );
    } catch (e) {
      _log.e('Drive file parse failed ${file.name}: $e');
      return null;
    }
  }

  Future<void> signOut() => driveService.signOut();
  bool get isSignedIn => driveService.isSignedIn;
  bool get hasDriveAccess => driveService.hasDriveAccess;
  String? get userEmail => driveService.currentUserEmail;
}
