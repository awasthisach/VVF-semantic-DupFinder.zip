import '../models/scanned_file.dart';
import '../../services/ai/embedding_service.dart';

class AiRepository {
  final EmbeddingService embeddingService;

  // In-memory cache so threshold change doesn't re-embed
  final List<DuplicatePair> _cachedPairs = [];

  AiRepository({required this.embeddingService});

  Future<DocumentEmbedding> generateEmbedding(ScannedFile file) async {
    final vector = await embeddingService.embed(file.textContent ?? '');
    return DocumentEmbedding(
      fileId: file.id,
      fileName: file.name,
      filePath: file.path,
      vector: vector,
      scannedAt: file.scannedAt,
    );
  }

  Future<List<DuplicatePair>> findDuplicates(
    List<DocumentEmbedding> embeddings, {
    double threshold = 0.87,
  }) async {
    final allPairs =
        await embeddingService.findDuplicates(embeddings, threshold: 0.80);
    // Cache all pairs (low threshold) so we can re-filter cheaply
    _cachedPairs
      ..clear()
      ..addAll(allPairs);
    return _cachedPairs.where((p) => p.similarity >= threshold).toList();
  }

  /// Re-filter cached pairs without re-embedding — fast threshold changes.
  Future<List<DuplicatePair>> getCachedPairs({required double threshold}) async {
    return _cachedPairs.where((p) => p.similarity >= threshold).toList();
  }

  void clearCache() => _cachedPairs.clear();
}
