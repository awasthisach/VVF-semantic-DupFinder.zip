import 'package:get_it/get_it.dart';

import '../../features/scan/bloc/scan_bloc.dart';
import '../../features/duplicate/bloc/duplicate_bloc.dart';
import '../../features/sort/bloc/sort_bloc.dart';
import '../../services/ai/embedding_service.dart';
import '../../services/drive/google_drive_service.dart';
import '../../services/files/file_scanner_service.dart';
import '../../services/files/doc_parser_service.dart';
import '../../data/repositories/file_repository.dart';
import '../../data/repositories/ai_repository.dart';
import '../../data/repositories/drive_repository.dart';

final GetIt sl = GetIt.instance;

Future<void> setupDependencies() async {
  // ── Services (singletons) ──────────────────────────────
  sl.registerSingletonAsync<EmbeddingService>(() async {
    final service = EmbeddingService();
    await service.initialize(); // Load on-device model
    return service;
  });

  sl.registerSingleton<GoogleDriveService>(GoogleDriveService());
  sl.registerSingleton<FileScannerService>(FileScannerService());
  sl.registerSingleton<DocParserService>(DocParserService());

  await sl.isReady<EmbeddingService>();

  // ── Repositories ──────────────────────────────────────
  sl.registerSingleton<FileRepository>(
    FileRepository(scanner: sl<FileScannerService>()),
  );
  sl.registerSingleton<AiRepository>(
    AiRepository(embeddingService: sl<EmbeddingService>()),
  );
  sl.registerSingleton<DriveRepository>(
    DriveRepository(
      driveService: sl<GoogleDriveService>(),
      parserService: sl<DocParserService>(),
    ),
  );

  // ── BLoCs (factories - new instance per screen) ────────
  sl.registerFactory<ScanBloc>(() => ScanBloc(
        fileRepo: sl<FileRepository>(),
        driveRepo: sl<DriveRepository>(),
        parserService: sl<DocParserService>(),
      ));

  sl.registerFactory<DuplicateBloc>(() => DuplicateBloc(
        aiRepo: sl<AiRepository>(),
      ));

  sl.registerFactory<SortBloc>(() => SortBloc(
        fileRepo: sl<FileRepository>(),
      ));
}
