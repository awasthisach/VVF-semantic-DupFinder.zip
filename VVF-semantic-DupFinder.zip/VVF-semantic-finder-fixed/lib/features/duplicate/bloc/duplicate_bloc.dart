import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/models/scanned_file.dart';
import '../../../data/repositories/ai_repository.dart';
import '../../../services/ai/embedding_service.dart';

// ════════════════════════════════════════════════════════
// EVENTS
// ════════════════════════════════════════════════════════
abstract class DuplicateEvent extends Equatable {
  const DuplicateEvent();
  @override
  List<Object?> get props => [];
}

class AnalyzeDuplicatesEvent extends DuplicateEvent {
  final List<ScannedFile> files;
  final double similarityThreshold;

  const AnalyzeDuplicatesEvent({
    required this.files,
    this.similarityThreshold = 0.87, // 2026 recommended default
  });

  @override
  List<Object?> get props => [files, similarityThreshold];
}

class UpdateThresholdEvent extends DuplicateEvent {
  final double threshold;
  const UpdateThresholdEvent(this.threshold);
  @override
  List<Object?> get props => [threshold];
}

class DeleteDuplicateEvent extends DuplicateEvent {
  final String fileId;
  const DeleteDuplicateEvent(this.fileId);
  @override
  List<Object?> get props => [fileId];
}

class KeepAllEvent extends DuplicateEvent {
  final String groupId;
  const KeepAllEvent(this.groupId);
}

// ════════════════════════════════════════════════════════
// STATES
// ════════════════════════════════════════════════════════
abstract class DuplicateState extends Equatable {
  const DuplicateState();
  @override
  List<Object?> get props => [];
}

class DuplicateInitial extends DuplicateState {}

class DuplicateEmbedding extends DuplicateState {
  final int processed;
  final int total;

  const DuplicateEmbedding({required this.processed, required this.total});
  double get progress => total == 0 ? 0 : processed / total;

  @override
  List<Object?> get props => [processed, total];
}

class DuplicateAnalyzing extends DuplicateState {
  final String message;
  const DuplicateAnalyzing(this.message);
  @override
  List<Object?> get props => [message];
}

class DuplicateFound extends DuplicateState {
  final List<DuplicateGroup> groups;
  final int totalFilesAnalyzed;
  final double threshold;
  final int spaceSavedBytes;

  const DuplicateFound({
    required this.groups,
    required this.totalFilesAnalyzed,
    required this.threshold,
    required this.spaceSavedBytes,
  });

  int get totalDuplicates =>
      groups.fold(0, (sum, g) => sum + g.duplicates.length);

  String get spaceSavedFormatted {
    if (spaceSavedBytes > 1024 * 1024 * 1024) {
      return '${(spaceSavedBytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    } else if (spaceSavedBytes > 1024 * 1024) {
      return '${(spaceSavedBytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(spaceSavedBytes / 1024).toStringAsFixed(0)} KB';
  }

  @override
  List<Object?> get props => [groups, totalFilesAnalyzed, threshold];
}

class DuplicateNoneFound extends DuplicateState {
  final int filesAnalyzed;
  const DuplicateNoneFound(this.filesAnalyzed);
  @override
  List<Object?> get props => [filesAnalyzed];
}

class DuplicateError extends DuplicateState {
  final String message;
  const DuplicateError(this.message);
  @override
  List<Object?> get props => [message];
}

// ════════════════════════════════════════════════════════
// BLOC
// ════════════════════════════════════════════════════════
class DuplicateBloc extends Bloc<DuplicateEvent, DuplicateState> {
  final AiRepository aiRepo;
  List<DuplicatePair> _cachedPairs = [];
  List<ScannedFile> _cachedFiles = [];

  DuplicateBloc({required this.aiRepo}) : super(DuplicateInitial()) {
    on<AnalyzeDuplicatesEvent>(_onAnalyze);
    on<UpdateThresholdEvent>(_onUpdateThreshold);
    on<DeleteDuplicateEvent>(_onDelete);
    on<KeepAllEvent>(_onKeepAll);
  }

  Future<void> _onAnalyze(
    AnalyzeDuplicatesEvent event,
    Emitter<DuplicateState> emit,
  ) async {
    if (event.files.isEmpty) {
      emit(const DuplicateNoneFound(0));
      return;
    }

    try {
      // Phase 1: Generate embeddings for all documents
      final embeddings = <DocumentEmbedding>[];

      for (int i = 0; i < event.files.length; i++) {
        emit(DuplicateEmbedding(processed: i, total: event.files.length));

        final file = event.files[i];
        if (file.textContent == null || file.textContent!.isEmpty) continue;

        final embedding = await aiRepo.generateEmbedding(file);
        embeddings.add(embedding);
      }

      // Phase 2: Find duplicate pairs using cosine similarity
      emit(const DuplicateAnalyzing('Finding semantic duplicates...'));

      final pairs = await aiRepo.findDuplicates(
        embeddings,
        threshold: event.similarityThreshold,
      );
      
      // Cache pairs for threshold updates
      _cachedPairs = pairs;
      _cachedFiles = event.files;

      if (pairs.isEmpty) {
        emit(DuplicateNoneFound(event.files.length));
        return;
      }

      // Phase 3: Cluster pairs into groups
      emit(const DuplicateAnalyzing('Grouping duplicate clusters...'));
      final groups = _clusterPairsIntoGroups(pairs);

      // Calculate space that can be saved
      final spaceSaved = _calculateSavings(groups, event.files);

      emit(DuplicateFound(
        groups: groups,
        totalFilesAnalyzed: event.files.length,
        threshold: event.similarityThreshold,
        spaceSavedBytes: spaceSaved,
      ));
    } catch (e) {
      emit(DuplicateError('Analysis failed: $e'));
    }
  }

  /// Re-runs analysis with new threshold (no re-embedding needed)
  Future<void> _onUpdateThreshold(
    UpdateThresholdEvent event,
    Emitter<DuplicateState> emit,
  ) async {
    if (state is DuplicateFound) {
      // Just filter existing pairs by new threshold
      final current = state as DuplicateFound;
      emit(const DuplicateAnalyzing('Applying new threshold...'));

      final pairs = await aiRepo.getCachedPairs(threshold: event.threshold);
      if (pairs.isEmpty) {
        emit(DuplicateNoneFound(current.totalFilesAnalyzed));
        return;
      }

      final groups = _clusterPairsIntoGroups(pairs);
      final spaceSaved = _calculateSavings(groups, _cachedFiles);
      
      emit(DuplicateFound(
        groups: groups,
        totalFilesAnalyzed: current.totalFilesAnalyzed,
        threshold: event.threshold,
        spaceSavedBytes: spaceSaved,
      ));
    }
  }

  Future<void> _onDelete(
    DeleteDuplicateEvent event,
    Emitter<DuplicateState> emit,
  ) async {
    // Delete functionality is handled by FileRepository in the UI layer
    // This is a placeholder for future state management of deletions
    if (state is DuplicateFound) {
      final current = state as DuplicateFound;
      // In a full implementation, refresh the groups after deletion
      emit(current);
    }
  }

  Future<void> _onKeepAll(
    KeepAllEvent event,
    Emitter<DuplicateState> emit,
  ) async {
    // Placeholder for keep-all functionality
    if (state is DuplicateFound) {
      final current = state as DuplicateFound;
      emit(current);
    }
  }

  // ── Union-Find Clustering ───────────────────────────
  /// Groups overlapping duplicate pairs into clusters.
  /// e.g. if A≈B and B≈C, they all go into one group {A, B, C}
  List<DuplicateGroup> _clusterPairsIntoGroups(List<DuplicatePair> pairs) {
    final parent = <String, String>{};

    String find(String id) {
      parent[id] ??= id;
      if (parent[id] != id) parent[id] = find(parent[id]!);
      return parent[id]!;
    }

    void union(String a, String b) {
      final ra = find(a);
      final rb = find(b);
      if (ra != rb) parent[ra] = rb;
    }

    // Build union-find
    for (final pair in pairs) {
      union(pair.docA.fileId, pair.docB.fileId);
    }

    // Collect all documents per cluster
    final clusters = <String, List<DocumentEmbedding>>{};
    final allDocs = <String, DocumentEmbedding>{};

    for (final pair in pairs) {
      allDocs[pair.docA.fileId] = pair.docA;
      allDocs[pair.docB.fileId] = pair.docB;
    }

    for (final doc in allDocs.values) {
      final root = find(doc.fileId);
      clusters.putIfAbsent(root, () => []).add(doc);
    }

    // Build DuplicateGroup list
    return clusters.entries
        .where((e) => e.value.length > 1)
        .map((e) {
          final docs = e.value;
          final groupPairs = pairs
              .where((p) =>
                  find(p.docA.fileId) == e.key &&
                  find(p.docB.fileId) == e.key)
              .toList();

          final avgSimilarity = groupPairs.isEmpty
              ? 0.0
              : groupPairs.fold(0.0, (s, p) => s + p.similarity) /
                  groupPairs.length;

          return DuplicateGroup(
            id: e.key,
            original: docs.first, // Oldest file = original
            duplicates: docs.skip(1).toList(),
            averageSimilarity: avgSimilarity,
            category: DuplicateCategory.values.firstWhere(
              (c) =>
                  avgSimilarity >= _categoryThreshold(c),
              orElse: () => DuplicateCategory.similarContent,
            ),
          );
        })
        .toList()
      ..sort((a, b) => b.averageSimilarity.compareTo(a.averageSimilarity));
  }

  double _categoryThreshold(DuplicateCategory cat) {
    switch (cat) {
      case DuplicateCategory.exactCopy:
        return 0.98;
      case DuplicateCategory.nearDuplicate:
        return 0.90;
      case DuplicateCategory.similarContent:
        return 0.85;
    }
  }

  int _calculateSavings(
      List<DuplicateGroup> groups, List<ScannedFile> files) {
    final sizeMap = {for (final f in files) f.id: f.sizeBytes};
    return groups.fold(0, (total, group) {
      return total +
          group.duplicates.fold(
              0, (sum, doc) => sum + (sizeMap[doc.fileId] ?? 0));
    });
  }
}

// ── Data Models ─────────────────────────────────────────
class DuplicateGroup {
  final String id;
  final DocumentEmbedding original;
  final List<DocumentEmbedding> duplicates;
  final double averageSimilarity;
  final DuplicateCategory category;

  const DuplicateGroup({
    required this.id,
    required this.original,
    required this.duplicates,
    required this.averageSimilarity,
    required this.category,
  });

  String get similarityPercent =>
      '${(averageSimilarity * 100).toStringAsFixed(1)}%';

  int get totalCount => 1 + duplicates.length;
}
