import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../bloc/duplicate_bloc.dart';
import '../../../services/ai/embedding_service.dart';

class DuplicateResultsScreen extends StatefulWidget {
  const DuplicateResultsScreen({super.key});

  @override
  State<DuplicateResultsScreen> createState() =>
      _DuplicateResultsScreenState();
}

class _DuplicateResultsScreenState extends State<DuplicateResultsScreen> {
  double _threshold = 0.87;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Duplicate files'),
        actions: [
          IconButton(
            icon: const Icon(Icons.tune),
            onPressed: _showThresholdSheet,
            tooltip: 'Sensitivity',
          ),
        ],
      ),
      body: BlocBuilder<DuplicateBloc, DuplicateState>(
        builder: (context, state) {
          if (state is DuplicateAnalyzing) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: 16),
                  Text(state.message),
                ],
              ),
            );
          }

          if (state is DuplicateNoneFound) {
            return _NoneFoundView(filesAnalyzed: state.filesAnalyzed);
          }

          if (state is DuplicateFound) {
            return _ResultsBody(state: state, threshold: _threshold);
          }

          return const SizedBox();
        },
      ),
    );
  }

  void _showThresholdSheet() {
    showModalBottomSheet(
      context: context,
      builder: (_) => BlocProvider.value(
        value: context.read<DuplicateBloc>(),
        child: _ThresholdSheet(
          threshold: _threshold,
          onChanged: (val) {
            setState(() => _threshold = val);
            context
                .read<DuplicateBloc>()
                .add(UpdateThresholdEvent(val));
          },
        ),
      ),
    );
  }
}

// ── Results Body ────────────────────────────────────────
class _ResultsBody extends StatelessWidget {
  final DuplicateFound state;
  final double threshold;
  const _ResultsBody({required this.state, required this.threshold});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Summary bar
        Container(
          color: Theme.of(context).colorScheme.primaryContainer,
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _StatChip(
                  label: '${state.groups.length}',
                  sub: 'Groups',
                  color: Colors.orange),
              _StatChip(
                  label: '${state.totalDuplicates}',
                  sub: 'Duplicates',
                  color: Colors.red),
              _StatChip(
                  label: state.spaceSavedFormatted,
                  sub: 'Saveable',
                  color: Colors.green),
              _StatChip(
                  label: '${(threshold * 100).toInt()}%',
                  sub: 'Threshold',
                  color: Colors.blue),
            ],
          ),
        ),

        // Group list
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: state.groups.length,
            itemBuilder: (context, i) {
              return _DuplicateGroupCard(
                group: state.groups[i],
                index: i,
              ).animate(delay: Duration(milliseconds: i * 60)).fadeIn().slideX(begin: 0.1);
            },
          ),
        ),
      ],
    );
  }
}

// ── Duplicate Group Card ────────────────────────────────
class _DuplicateGroupCard extends StatefulWidget {
  final DuplicateGroup group;
  final int index;
  const _DuplicateGroupCard(
      {required this.group, required this.index});

  @override
  State<_DuplicateGroupCard> createState() =>
      _DuplicateGroupCardState();
}

class _DuplicateGroupCardState extends State<_DuplicateGroupCard> {
  bool _expanded = false;

  Color get _categoryColor {
    switch (widget.group.category) {
      case DuplicateCategory.exactCopy:
        return Colors.red;
      case DuplicateCategory.nearDuplicate:
        return Colors.orange;
      case DuplicateCategory.similarContent:
        return Colors.amber;
    }
  }

  String get _categoryLabel {
    switch (widget.group.category) {
      case DuplicateCategory.exactCopy:
        return 'Exact copy';
      case DuplicateCategory.nearDuplicate:
        return 'Near duplicate';
      case DuplicateCategory.similarContent:
        return 'Similar content';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          // Header — tap to expand/collapse
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: BorderRadius.circular(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  // Similarity badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _categoryColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      widget.group.similarityPercent,
                      style: TextStyle(
                        color: _categoryColor,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.group.original.fileName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.bodyMedium
                              ?.copyWith(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          '$_categoryLabel · ${widget.group.totalCount} files',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: _categoryColor),
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    _expanded
                        ? Icons.keyboard_arrow_up
                        : Icons.keyboard_arrow_down,
                  ),
                ],
              ),
            ),
          ),

          // Expanded: list all files with delete option
          if (_expanded) ...[
            const Divider(height: 1),
            // Original
            _FileRow(
              doc: widget.group.original,
              isOriginal: true,
              onDelete: null, // Never delete the original
            ),
            // Duplicates
            ...widget.group.duplicates.map(
              (doc) => Dismissible(
                key: Key(doc.fileId),
                direction: DismissDirection.endToStart,
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.only(right: 20),
                  color: Colors.red,
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                confirmDismiss: (_) => _confirmDelete(context, doc.fileName),
                onDismissed: (_) {
                  context
                      .read<DuplicateBloc>()
                      .add(DeleteDuplicateEvent(doc.fileId));
                },
                child: _FileRow(
                  doc: doc,
                  isOriginal: false,
                  onDelete: () {
                    context
                        .read<DuplicateBloc>()
                        .add(DeleteDuplicateEvent(doc.fileId));
                  },
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext ctx, String name) async {
    final result = await showDialog<bool>(
      context: ctx,
      builder: (dialogCtx) => AlertDialog(
        title: const Text('Delete file?'),
        content: Text('Delete "$name"?\nThis cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogCtx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogCtx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    return result ?? false;
  }
}

// ── File Row ─────────────────────────────────────────────
class _FileRow extends StatelessWidget {
  final DocumentEmbedding doc;
  final bool isOriginal;
  final VoidCallback? onDelete;

  const _FileRow({
    required this.doc,
    required this.isOriginal,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      leading: Icon(
        _fileIcon(doc.filePath),
        size: 20,
        color: isOriginal ? Colors.green : Colors.grey,
      ),
      title: Text(
        doc.fileName,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 13,
          color: isOriginal
              ? Theme.of(context).colorScheme.primary
              : null,
        ),
      ),
      subtitle: Text(
        isOriginal ? 'Original (keep)' : doc.filePath,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(fontSize: 11),
      ),
      trailing: isOriginal
          ? const Chip(
              label: Text('Keep', style: TextStyle(fontSize: 11)),
              visualDensity: VisualDensity.compact,
            )
          : IconButton(
              icon: const Icon(Icons.delete_outline,
                  size: 18, color: Colors.red),
              onPressed: onDelete,
              tooltip: 'Delete this duplicate',
            ),
    );
  }

  IconData _fileIcon(String path) {
    final ext = path.split('.').last.toLowerCase();
    switch (ext) {
      case 'pdf':
        return Icons.picture_as_pdf_outlined;
      case 'docx':
      case 'doc':
        return Icons.description_outlined;
      case 'jpg':
      case 'jpeg':
      case 'png':
        return Icons.image_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }
}

// ── Threshold Sheet ───────────────────────────────────────
class _ThresholdSheet extends StatefulWidget {
  final double threshold;
  final ValueChanged<double> onChanged;
  const _ThresholdSheet(
      {required this.threshold, required this.onChanged});

  @override
  State<_ThresholdSheet> createState() => _ThresholdSheetState();
}

class _ThresholdSheetState extends State<_ThresholdSheet> {
  late double _val;

  @override
  void initState() {
    super.initState();
    _val = widget.threshold;
  }

  String get _label {
    if (_val >= 0.98) return 'Exact copies only';
    if (_val >= 0.92) return 'Near duplicates';
    if (_val >= 0.85) return 'Similar content (recommended)';
    return 'Loosely related';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Similarity sensitivity',
              style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(
            _label,
            style: TextStyle(
              color: Theme.of(context).colorScheme.primary,
              fontWeight: FontWeight.w500,
            ),
          ),
          Row(
            children: [
              const Text('80%', style: TextStyle(fontSize: 12)),
              Expanded(
                child: Slider(
                  min: 0.80,
                  max: 0.99,
                  divisions: 19,
                  value: _val,
                  label: '${(_val * 100).toInt()}%',
                  onChanged: (v) {
                    setState(() => _val = v);
                    widget.onChanged(v);
                  },
                ),
              ),
              const Text('99%', style: TextStyle(fontSize: 12)),
            ],
          ),
          const SizedBox(height: 4),
          // Category legend
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: const [
              _Legend(color: Colors.amber, label: '80–85% loose'),
              _Legend(color: Colors.orange, label: '85–90% similar'),
              _Legend(color: Colors.red, label: '98%+ exact'),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(width: 10, height: 10, color: color),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 10)),
      ],
    );
  }
}

// ── None Found View ──────────────────────────────────────
class _NoneFoundView extends StatelessWidget {
  final int filesAnalyzed;
  const _NoneFoundView({required this.filesAnalyzed});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.check_circle_outline,
              size: 72, color: Colors.green),
          const SizedBox(height: 16),
          Text('No duplicates found',
              style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('All $filesAnalyzed files are unique!',
              style: Theme.of(context).textTheme.bodyMedium),
        ],
      ),
    );
  }
}

// ── Stat Chip ─────────────────────────────────────────────
class _StatChip extends StatelessWidget {
  final String label, sub;
  final Color color;
  const _StatChip(
      {required this.label, required this.sub, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label,
            style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color)),
        Text(sub,
            style: const TextStyle(fontSize: 11, color: Colors.grey)),
      ],
    );
  }
}
