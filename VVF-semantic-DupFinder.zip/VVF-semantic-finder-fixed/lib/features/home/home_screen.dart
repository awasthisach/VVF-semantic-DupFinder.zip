import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:file_picker/file_picker.dart';

import '../scan/bloc/scan_bloc.dart';
import '../duplicate/bloc/duplicate_bloc.dart';
import '../sort/bloc/sort_bloc.dart';
import '../scan/widgets/scan_progress_card.dart';
import '../duplicate/screens/duplicate_results_screen.dart';
import '../sort/screens/sort_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Semantic File Finder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
          ),
        ],
      ),
      body: BlocConsumer<ScanBloc, ScanState>(
        listener: (context, state) {
          if (state is ScanComplete) {
            if (state.files.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('No supported files found.')));
              return;
            }
            final secs = state.elapsed.inSeconds;
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('${state.files.length} files scanned in ${secs}s'
                  '${state.failedCount > 0 ? " · ${state.failedCount} skipped" : ""}'),
              duration: const Duration(seconds: 3),
            ));
            context
                .read<DuplicateBloc>()
                .add(AnalyzeDuplicatesEvent(files: state.files));
            context.read<SortBloc>().add(LoadFilesForSort(state.files));
          }
          if (state is ScanError) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(state.message),
                backgroundColor: Colors.red));
          }
        },
        builder: (context, scanState) {
          return BlocBuilder<DuplicateBloc, DuplicateState>(
            builder: (context, dupState) {
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  if (dupState is DuplicateFound)
                    _StatsBar(state: dupState)
                        .animate()
                        .fadeIn(duration: 400.ms)
                        .slideY(begin: -0.2),
                  if (dupState is DuplicateFound)
                    const SizedBox(height: 24),

                  Text('Scan sources',
                      style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),

                  _ScanSourceGrid(
                    isScanning: scanState is ScanInProgress,
                    onLocalTap: () => context
                        .read<ScanBloc>()
                        .add(const ScanLocalStorageEvent()),
                    onDriveTap: () => context
                        .read<ScanBloc>()
                        .add(const ScanGoogleDriveEvent()),
                    onPickTap: () => _pickFiles(context),
                  ),

                  const SizedBox(height: 24),

                  if (scanState is ScanInProgress)
                    ScanProgressCard(state: scanState),
                  if (dupState is DuplicateEmbedding)
                    _EmbeddingCard(state: dupState).animate().fadeIn(),
                  if (dupState is DuplicateAnalyzing)
                    _AnalyzingCard(dupState.message).animate().fadeIn(),

                  if (dupState is DuplicateFound ||
                      context.read<SortBloc>().state is SortLoaded)
                    _QuickActions(
                      duplicateCount: dupState is DuplicateFound
                          ? dupState.totalDuplicates
                          : 0,
                      onDuplicates: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => BlocProvider.value(
                                    value: context.read<DuplicateBloc>(),
                                    child: const DuplicateResultsScreen(),
                                  ))),
                      onSort: () {
                        final s = context.read<SortBloc>().state;
                        if (s is SortLoaded) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => BlocProvider.value(
                                        value: context.read<SortBloc>(),
                                        child:
                                            SortScreen(files: s.allFiles),
                                      )));
                        }
                      },
                    ).animate().fadeIn(duration: 500.ms),

                  if (dupState is DuplicateFound) ...[
                    const SizedBox(height: 24),
                    _ResultsSummary(
                      state: dupState,
                      onViewAll: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => BlocProvider.value(
                                    value: context.read<DuplicateBloc>(),
                                    child: const DuplicateResultsScreen(),
                                  ))),
                    ).animate().fadeIn(duration: 600.ms),
                  ],

                  if (dupState is DuplicateNoneFound)
                    _NoneFoundCard(dupState.filesAnalyzed).animate().fadeIn(),

                  const SizedBox(height: 80),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _pickFiles(BuildContext context) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'docx', 'doc', 'txt', 'jpg', 'jpeg', 'png'],
    );
    if (result != null && context.mounted) {
      context.read<ScanBloc>().add(
          ScanSelectedFilesEvent(result.paths.whereType<String>().toList()));
    }
  }
}

// ── Widgets ────────────────────────────────────────────────
class _ScanSourceGrid extends StatelessWidget {
  final bool isScanning;
  final VoidCallback onLocalTap, onDriveTap, onPickTap;
  const _ScanSourceGrid(
      {required this.isScanning,
      required this.onLocalTap,
      required this.onDriveTap,
      required this.onPickTap});

  @override
  Widget build(BuildContext context) => GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1,
        children: [
          _Tile(Icons.phone_android_outlined, 'Local files', Colors.blue,
              isScanning ? null : onLocalTap),
          _Tile(Icons.cloud_outlined, 'Google Drive', Colors.green,
              isScanning ? null : onDriveTap),
          _Tile(Icons.add_circle_outline, 'Pick files', Colors.orange,
              isScanning ? null : onPickTap),
        ],
      );
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  const _Tile(this.icon, this.label, this.color, this.onTap);

  @override
  Widget build(BuildContext context) {
    final on = onTap != null;
    return Material(
      color: color.withOpacity(on ? 0.10 : 0.04),
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 32, color: color.withOpacity(on ? 1 : 0.3)),
            const SizedBox(height: 8),
            Text(label,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: on
                        ? null
                        : Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.3)),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _StatsBar extends StatelessWidget {
  final DuplicateFound state;
  const _StatsBar({required this.state});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.08),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.red.withOpacity(0.18)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _S('${state.totalDuplicates}', 'Duplicates', Colors.red),
            _S('${state.groups.length}', 'Groups', Colors.orange),
            _S(state.spaceSavedFormatted, 'Saveable', Colors.green),
          ],
        ),
      );
}

class _S extends StatelessWidget {
  final String v, l;
  final Color c;
  const _S(this.v, this.l, this.c);

  @override
  Widget build(BuildContext context) => Column(children: [
        Text(v,
            style: TextStyle(
                fontSize: 22, fontWeight: FontWeight.bold, color: c)),
        Text(l, style: Theme.of(context).textTheme.bodySmall),
      ]);
}

class _QuickActions extends StatelessWidget {
  final int duplicateCount;
  final VoidCallback onDuplicates, onSort;
  const _QuickActions(
      {required this.duplicateCount,
      required this.onDuplicates,
      required this.onSort});

  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
          child: _ActionBtn(
            icon: Icons.copy_outlined,
            label: duplicateCount > 0
                ? 'View $duplicateCount duplicates'
                : 'No duplicates',
            color: Colors.red,
            onTap: duplicateCount > 0 ? onDuplicates : null,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _ActionBtn(
            icon: Icons.sort_outlined,
            label: 'Browse & sort',
            color: Colors.blue,
            onTap: onSort,
          ),
        ),
      ]);
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  const _ActionBtn(
      {required this.icon,
      required this.label,
      required this.color,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    final on = onTap != null;
    return Material(
      color: color.withOpacity(on ? 0.1 : 0.04),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Row(children: [
            Icon(icon,
                size: 20, color: color.withOpacity(on ? 1 : 0.3)),
            const SizedBox(width: 8),
            Expanded(
                child: Text(label,
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: color.withOpacity(on ? 1 : 0.3)),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis)),
          ]),
        ),
      ),
    );
  }
}

class _EmbeddingCard extends StatelessWidget {
  final DuplicateEmbedding state;
  const _EmbeddingCard({required this.state});

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2)),
                const SizedBox(width: 10),
                Text(
                    'Embedding ${state.processed}/${state.total} documents'),
              ]),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: state.progress),
              const SizedBox(height: 4),
              Text('EmbeddingGemma 3 · on-device',
                  style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      );
}

class _AnalyzingCard extends StatelessWidget {
  final String msg;
  const _AnalyzingCard(this.msg);

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2)),
            const SizedBox(width: 12),
            Text(msg),
          ]),
        ),
      );
}

class _ResultsSummary extends StatelessWidget {
  final DuplicateFound state;
  final VoidCallback onViewAll;
  const _ResultsSummary({required this.state, required this.onViewAll});

  @override
  Widget build(BuildContext context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Top groups',
                  style: Theme.of(context).textTheme.titleMedium),
              TextButton(onPressed: onViewAll, child: const Text('See all')),
            ],
          ),
          ...state.groups.take(3).map((g) => Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.red.withOpacity(0.1),
                    child: Text('${g.totalCount}',
                        style: const TextStyle(
                            color: Colors.red,
                            fontWeight: FontWeight.bold)),
                  ),
                  title: Text(g.original.fileName,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(
                      '${g.similarityPercent} match · ${g.duplicates.length} duplicate(s)'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: onViewAll,
                ),
              )),
        ],
      );
}

class _NoneFoundCard extends StatelessWidget {
  final int n;
  const _NoneFoundCard(this.n);

  @override
  Widget build(BuildContext context) => Card(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(children: [
            const Icon(Icons.check_circle_outline,
                size: 52, color: Colors.green),
            const SizedBox(height: 12),
            Text('No duplicates found',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text('Analyzed $n files — all unique!',
                style: Theme.of(context).textTheme.bodySmall),
          ]),
        ),
      );
}
