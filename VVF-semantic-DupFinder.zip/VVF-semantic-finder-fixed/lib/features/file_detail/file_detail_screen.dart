import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';

import '../../../data/models/scanned_file.dart';

class FileDetailScreen extends StatelessWidget {
  final ScannedFile file;

  const FileDetailScreen({super.key, required this.file});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          file.name,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy_outlined),
            tooltip: 'Copy path',
            onPressed: () {
              Clipboard.setData(ClipboardData(text: file.path));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Path copied to clipboard'),
                  duration: Duration(seconds: 2),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ── File icon + name ────────────────────────
          Center(
            child: Column(
              children: [
                _BigFileIcon(ext: file.extension),
                const SizedBox(height: 16),
                Text(
                  file.name,
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w600),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text(
                  file.extension.toUpperCase(),
                  style: TextStyle(
                    color: _extColor(file.extension),
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ).animate().fadeIn().scale(begin: const Offset(0.8, 0.8)),

          const SizedBox(height: 28),

          // ── Metadata card ───────────────────────────
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('File info',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          )),
                  const SizedBox(height: 12),
                  _InfoRow(Icons.folder_outlined, 'Location', file.path),
                  _InfoRow(Icons.data_usage_outlined, 'Size',
                      file.sizeFormatted),
                  _InfoRow(
                      Icons.calendar_today_outlined,
                      'Modified',
                      DateFormat('dd MMM yyyy, HH:mm')
                          .format(file.modifiedAt)),
                  _InfoRow(
                      Icons.access_time_outlined,
                      'Scanned',
                      DateFormat('dd MMM yyyy, HH:mm')
                          .format(file.scannedAt)),
                  _InfoRow(
                      Icons.source_outlined,
                      'Source',
                      file.source == FileSource.googleDrive
                          ? 'Google Drive'
                          : 'Local storage'),
                ],
              ),
            ),
          ).animate().fadeIn(delay: 100.ms).slideY(begin: 0.2),

          const SizedBox(height: 16),

          // ── Text preview card ───────────────────────
          if (file.hasText) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Text preview',
                            style: Theme.of(context)
                                .textTheme
                                .labelMedium
                                ?.copyWith(
                                  color:
                                      Theme.of(context).colorScheme.primary,
                                  fontWeight: FontWeight.bold,
                                )),
                        const Spacer(),
                        Text(
                          '${file.textContent!.length} chars',
                          style:
                              Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Theme.of(context)
                            .colorScheme
                            .surfaceVariant
                            .withOpacity(0.5),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        file.textContent!.length > 600
                            ? '${file.textContent!.substring(0, 600)}…'
                            : file.textContent!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontFamily: 'monospace',
                              height: 1.5,
                            ),
                      ),
                    ),
                  ],
                ),
              ),
            ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.2),
          ] else ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.warning_amber_outlined,
                        color: Colors.orange.shade600),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'No text extracted from this file. It may be a scanned image or unsupported format.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],

          const SizedBox(height: 16),

          // ── AI status card ──────────────────────────
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('AI embedding',
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.bold,
                          )),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Icon(
                        file.hasText
                            ? Icons.check_circle_outline
                            : Icons.cancel_outlined,
                        color: file.hasText ? Colors.green : Colors.grey,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        file.hasText
                            ? 'Ready for semantic analysis'
                            : 'Cannot embed — no text content',
                        style: TextStyle(
                          color:
                              file.hasText ? Colors.green : Colors.grey,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  if (file.hasText) ...[
                    const SizedBox(height: 8),
                    Text(
                      'EmbeddingGemma 3 will convert this file\'s text into a 768-dimensional vector for semantic comparison.',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Colors.grey.shade600,
                          ),
                    ),
                  ],
                ],
              ),
            ),
          ).animate().fadeIn(delay: 300.ms).slideY(begin: 0.2),

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Color _extColor(String ext) {
    switch (ext.toLowerCase()) {
      case 'pdf': return Colors.red;
      case 'docx': case 'doc': return Colors.blue;
      case 'txt': case 'md': return Colors.teal;
      case 'jpg': case 'jpeg': case 'png': return Colors.orange;
      default: return Colors.grey;
    }
  }
}

// ── Big File Icon ────────────────────────────────────────
class _BigFileIcon extends StatelessWidget {
  final String ext;
  const _BigFileIcon({required this.ext});

  @override
  Widget build(BuildContext context) {
    Color c;
    IconData ic;
    switch (ext.toLowerCase()) {
      case 'pdf': c = Colors.red; ic = Icons.picture_as_pdf_outlined; break;
      case 'docx': case 'doc': c = Colors.blue; ic = Icons.description_outlined; break;
      case 'txt': case 'md': c = Colors.teal; ic = Icons.article_outlined; break;
      case 'jpg': case 'jpeg': case 'png': c = Colors.orange; ic = Icons.image_outlined; break;
      default: c = Colors.grey; ic = Icons.insert_drive_file_outlined;
    }
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        color: c.withOpacity(0.12),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Icon(ic, size: 52, color: c),
    );
  }
}

// ── Info Row ─────────────────────────────────────────────
class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 16, color: Colors.grey),
          const SizedBox(width: 10),
          SizedBox(
            width: 72,
            child: Text(label,
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: Colors.grey)),
          ),
          Expanded(
            child: Text(value,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w500,
                    )),
          ),
        ],
      ),
    );
  }
}
