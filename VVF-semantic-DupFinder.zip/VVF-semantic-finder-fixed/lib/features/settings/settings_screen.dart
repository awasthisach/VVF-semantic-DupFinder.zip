import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../../core/constants/app_constants.dart';
import '../../core/services/prefs_service.dart';
import '../../data/repositories/drive_repository.dart';
import '../../core/di/injection.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late double _threshold;
  late List<String> _enabledExts;
  bool _busy = false;

  final _driveRepo = sl<DriveRepository>();

  @override
  void initState() {
    super.initState();
    _threshold = PrefsService.savedThreshold;
    _enabledExts = List.from(PrefsService.enabledExtensions);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [

          // ─── AI Engine ────────────────────────────────
          _Hdr('AI Engine'),
          _Card(children: [
            ListTile(
              leading: const Icon(Icons.memory_outlined, color: Colors.green),
              title: const Text('On-device model'),
              subtitle: const Text('EmbeddingGemma 3 · 300M params · 768-dim'),
              trailing: _Chip('Active', Colors.green),
            ),
            ListTile(
              leading: const Icon(Icons.security_outlined, color: Colors.blue),
              title: const Text('Privacy mode'),
              subtitle: const Text('Files never leave your device'),
              trailing: const Icon(Icons.check_circle, color: Colors.green, size: 20),
            ),
          ]).animate().fadeIn(delay: 50.ms),

          // ─── Threshold ────────────────────────────────
          _Hdr('Duplicate sensitivity'),
          _Card(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(children: [
                const Text('Threshold', style: TextStyle(fontSize: 14)),
                const Spacer(),
                Text(
                  '${(_threshold * 100).toInt()}%',
                  style: TextStyle(
                    color: _tColor(_threshold),
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ]),
            ),
            Slider(
              min: AppConstants.minThreshold,
              max: AppConstants.maxThreshold,
              divisions: 19,
              value: _threshold,
              onChanged: (v) => setState(() => _threshold = v),
              onChangeEnd: (v) async {
                await PrefsService.saveThreshold(v);
                if (mounted) _snack('Threshold saved: ${(v * 100).toInt()}%');
              },
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
              child: Text(
                _tLabel(_threshold),
                style: TextStyle(fontSize: 12, color: _tColor(_threshold), fontWeight: FontWeight.w500),
              ),
            ),
          ]).animate().fadeIn(delay: 100.ms),

          // ─── Scan file types ──────────────────────────
          _Hdr('Scan file types'),
          _Card(children: [
            ...AppConstants.supportedExtensions.map((ext) => SwitchListTile(
              dense: true,
              title: Text(ext.toUpperCase()),
              subtitle: Text(_extDesc(ext), style: const TextStyle(fontSize: 12)),
              value: _enabledExts.contains(ext),
              onChanged: (v) async {
                setState(() => v ? _enabledExts.add(ext) : _enabledExts.remove(ext));
                await PrefsService.saveExtensions(_enabledExts);
              },
            )),
          ]).animate().fadeIn(delay: 150.ms),

          // ─── Google Drive ─────────────────────────────
          _Hdr('Google Drive'),
          _Card(children: [
            ListTile(
              leading: Icon(
                Icons.account_circle_outlined,
                color: _driveRepo.isSignedIn ? Colors.green : Colors.grey,
              ),
              title: Text(_driveRepo.isSignedIn
                  ? (_driveRepo.userEmail ?? 'Signed in')
                  : 'Not connected'),
              subtitle: Text(_driveRepo.hasDriveAccess
                  ? 'Drive access granted ✓'
                  : _driveRepo.isSignedIn
                      ? 'Tap to grant Drive access'
                      : 'Sign in to scan Google Drive'),
              trailing: _busy
                  ? const SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : _driveRepo.isSignedIn
                      ? OutlinedButton(onPressed: _signOut, child: const Text('Sign out'))
                      : FilledButton(onPressed: _signIn, child: const Text('Sign in')),
            ),
            if (_driveRepo.isSignedIn && !_driveRepo.hasDriveAccess)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.drive_folder_upload_outlined, size: 18),
                  label: const Text('Grant Drive access'),
                  onPressed: _grantDrive,
                  style: OutlinedButton.styleFrom(
                      minimumSize: const Size(double.infinity, 44)),
                ),
              ),
          ]).animate().fadeIn(delay: 200.ms),

          // ─── About ────────────────────────────────────
          _Hdr('About'),
          _Card(children: [
            const ListTile(
              dense: true,
              leading: Icon(Icons.info_outline),
              title: Text('Version'),
              trailing: Text('1.0.0', style: TextStyle(color: Colors.grey)),
            ),
            const ListTile(
              dense: true,
              leading: Icon(Icons.code_outlined),
              title: Text('Stack'),
              subtitle: Text('Flutter · BLoC · EmbeddingGemma 3 · TFLite'),
            ),
            const ListTile(
              dense: true,
              leading: Icon(Icons.lock_outline),
              title: Text('License'),
              subtitle: Text('MIT — See LICENSE file'),
            ),
          ]).animate().fadeIn(delay: 250.ms),

          const SizedBox(height: 80),
        ],
      ),
    );
  }

  // ── Auth ─────────────────────────────────────────────
  Future<void> _signIn() async {
    setState(() => _busy = true);
    await _driveRepo.ensureDriveAccess();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _signOut() async {
    setState(() => _busy = true);
    await _driveRepo.signOut();
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _grantDrive() async {
    setState(() => _busy = true);
    await _driveRepo.ensureDriveAccess();
    if (mounted) setState(() => _busy = false);
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
      .showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));

  // ── Labels ───────────────────────────────────────────
  String _tLabel(double v) {
    if (v >= 0.97) return 'Exact copies only (very strict)';
    if (v >= 0.91) return 'Near duplicates — minor edits';
    if (v >= 0.85) return 'Similar content — recommended ✓';
    return 'Loosely related files';
  }

  Color _tColor(double v) {
    if (v >= 0.97) return Colors.red;
    if (v >= 0.91) return Colors.orange;
    if (v >= 0.85) return Colors.amber.shade700;
    return Colors.green;
  }

  String _extDesc(String ext) {
    const m = {
      'pdf': 'Portable Document Format',
      'docx': 'Microsoft Word 2007+',
      'doc': 'Legacy Word Document',
      'txt': 'Plain text file',
      'md': 'Markdown document',
      'jpg': 'JPEG image (OCR)',
      'jpeg': 'JPEG image (OCR)',
      'png': 'PNG image (OCR)',
    };
    return m[ext] ?? ext;
  }
}

// ── Small widgets ────────────────────────────────────────
class _Hdr extends StatelessWidget {
  final String t;
  const _Hdr(this.t);
  @override
  Widget build(BuildContext ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 20, 16, 6),
        child: Text(t.toUpperCase(),
            style: Theme.of(ctx).textTheme.labelSmall?.copyWith(
                color: Theme.of(ctx).colorScheme.primary,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.0)),
      );
}

class _Card extends StatelessWidget {
  final List<Widget> children;
  const _Card({required this.children});
  @override
  Widget build(BuildContext ctx) => Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: Column(children: children),
      );
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip(this.label, this.color);
  @override
  Widget build(BuildContext ctx) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label,
            style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
      );
}
