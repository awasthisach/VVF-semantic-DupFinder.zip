import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../bloc/scan_bloc.dart';

class ScanProgressCard extends StatelessWidget {
  final ScanInProgress state;
  const ScanProgressCard({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final srcIcon = state.source == ScanSource.googleDrive
        ? Icons.cloud_outlined
        : Icons.phone_android_outlined;
    final srcLabel = state.source == ScanSource.googleDrive
        ? 'Google Drive'
        : 'Local storage';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(srcIcon,
                    size: 18,
                    color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text('Scanning $srcLabel',
                    style: Theme.of(context).textTheme.titleSmall),
                const Spacer(),
                Text(
                  '${state.scanned}/${state.total}',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: state.progress,
                minHeight: 6,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.insert_drive_file_outlined,
                    size: 14, color: Colors.grey),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    state.currentFile,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey,
                        ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ).animate().fadeIn().slideY(begin: 0.3);
  }
}
