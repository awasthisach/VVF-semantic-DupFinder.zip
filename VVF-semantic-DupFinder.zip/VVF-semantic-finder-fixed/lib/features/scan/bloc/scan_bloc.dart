import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/models/scanned_file.dart';
import '../../../data/repositories/file_repository.dart';
import '../../../data/repositories/drive_repository.dart';
import '../../../services/files/doc_parser_service.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/services/prefs_service.dart';

// ════════════════════════════════════════════════════════
// EVENTS
// ════════════════════════════════════════════════════════
abstract class ScanEvent extends Equatable {
  const ScanEvent();
  @override
  List<Object?> get props => [];
}

class ScanLocalStorageEvent extends ScanEvent {
  final List<String> allowedExtensions;
  const ScanLocalStorageEvent({
    this.allowedExtensions = AppConstants.supportedExtensions,
  });
  @override
  List<Object?> get props => [allowedExtensions];
}

class ScanGoogleDriveEvent extends ScanEvent {
  final String? folderId;
  const ScanGoogleDriveEvent({this.folderId});
  @override
  List<Object?> get props => [folderId];
}

class ScanSelectedFilesEvent extends ScanEvent {
  final List<String> filePaths;
  const ScanSelectedFilesEvent(this.filePaths);
  @override
  List<Object?> get props => [filePaths];
}

class CancelScanEvent extends ScanEvent {}
class ClearScanEvent extends ScanEvent {}

// ════════════════════════════════════════════════════════
// STATES
// ════════════════════════════════════════════════════════
abstract class ScanState extends Equatable {
  const ScanState();
  @override
  List<Object?> get props => [];
}

class ScanInitial extends ScanState {}

class ScanInProgress extends ScanState {
  final String currentFile;
  final int scanned;
  final int total;
  final ScanSource source;

  const ScanInProgress({
    required this.currentFile,
    required this.scanned,
    required this.total,
    required this.source,
  });

  double get progress => total == 0 ? 0 : scanned / total;

  @override
  List<Object?> get props => [currentFile, scanned, total, source];
}

class ScanComplete extends ScanState {
  final List<ScannedFile> files;
  final Duration elapsed;
  final int failedCount;

  const ScanComplete({
    required this.files,
    required this.elapsed,
    this.failedCount = 0,
  });

  @override
  List<Object?> get props => [files, elapsed, failedCount];
}

class ScanError extends ScanState {
  final String message;
  final ScanErrorType errorType;

  const ScanError({required this.message, required this.errorType});

  @override
  List<Object?> get props => [message, errorType];
}

enum ScanSource { localStorage, googleDrive, selected }
enum ScanErrorType { permissionDenied, authFailed, networkError, unknown }

// ════════════════════════════════════════════════════════
// BLOC
// ════════════════════════════════════════════════════════
class ScanBloc extends Bloc<ScanEvent, ScanState> {
  final FileRepository fileRepo;
  final DriveRepository driveRepo;
  final DocParserService parserService;

  bool _isCancelled = false;

  ScanBloc({
    required this.fileRepo,
    required this.driveRepo,
    required this.parserService,
  }) : super(ScanInitial()) {
    on<ScanLocalStorageEvent>(_onScanLocal);
    on<ScanGoogleDriveEvent>(_onScanDrive);
    on<ScanSelectedFilesEvent>(_onScanSelected);
    on<CancelScanEvent>(_onCancel);
    on<ClearScanEvent>(_onClear);
  }

  // ── Scan Local Storage ───────────────────────────────
  Future<void> _onScanLocal(
    ScanLocalStorageEvent event,
    Emitter<ScanState> emit,
  ) async {
    _isCancelled = false;
    final stopwatch = Stopwatch()..start();
    int failedCount = 0;

    try {
      // 1. Discover all matching files
      final filePaths = await fileRepo.discoverFiles(
        extensions: event.allowedExtensions,
      );

      if (filePaths.isEmpty) {
        emit(const ScanComplete(files: [], elapsed: Duration.zero));
        return;
      }

      final scannedFiles = <ScannedFile>[];

      // 2. Parse each file for text content
      for (int i = 0; i < filePaths.length; i++) {
        if (_isCancelled) break;

        final path = filePaths[i];
        emit(ScanInProgress(
          currentFile: path.split('/').last,
          scanned: i + 1,
          total: filePaths.length,
          source: ScanSource.localStorage,
        ));

        try {
          final scanned = await parserService.parseFile(path);
          if (scanned != null) scannedFiles.add(scanned);
        } catch (_) {
          failedCount++;
        }
      }

      stopwatch.stop();
      emit(ScanComplete(
        files: scannedFiles,
        elapsed: stopwatch.elapsed,
        failedCount: failedCount,
      ));
    } catch (e) {
      emit(ScanError(
        message: e.toString(),
        errorType: ScanErrorType.unknown,
      ));
    }
  }

  // ── Scan Google Drive ────────────────────────────────
  Future<void> _onScanDrive(
    ScanGoogleDriveEvent event,
    Emitter<ScanState> emit,
  ) async {
    _isCancelled = false;
    final stopwatch = Stopwatch()..start();
    int failedCount = 0;

    try {
      // Incremental auth — request Drive scope now
      final hasAccess = await driveRepo.ensureDriveAccess();
      if (!hasAccess) {
        emit(const ScanError(
          message: 'Drive permission denied. Please grant access.',
          errorType: ScanErrorType.authFailed,
        ));
        return;
      }

      final driveFiles = await driveRepo.listDocuments(
        folderId: event.folderId,
      );

      final scannedFiles = <ScannedFile>[];

      for (int i = 0; i < driveFiles.length; i++) {
        if (_isCancelled) break;

        final file = driveFiles[i];
        emit(ScanInProgress(
          currentFile: file.name,
          scanned: i + 1,
          total: driveFiles.length,
          source: ScanSource.googleDrive,
        ));

        try {
          final scanned = await driveRepo.downloadAndParse(file);
          if (scanned != null) scannedFiles.add(scanned);
        } catch (_) {
          failedCount++;
        }
      }

      stopwatch.stop();
      await PrefsService.saveLastScanDate();
      emit(ScanComplete(
        files: scannedFiles,
        elapsed: stopwatch.elapsed,
        failedCount: failedCount,
      ));
    } catch (e) {
      emit(ScanError(
        message: e.toString(),
        errorType: ScanErrorType.networkError,
      ));
    }
  }

  Future<void> _onScanSelected(
    ScanSelectedFilesEvent event,
    Emitter<ScanState> emit,
  ) async {
    // Similar to _onScanLocal but for manually picked files
    _isCancelled = false;
    final stopwatch = Stopwatch()..start();
    int failedCount = 0;
    final scannedFiles = <ScannedFile>[];

    try {
      for (int i = 0; i < event.filePaths.length; i++) {
        if (_isCancelled) break;
        emit(ScanInProgress(
          currentFile: event.filePaths[i].split('/').last,
          scanned: i + 1,
          total: event.filePaths.length,
          source: ScanSource.selected,
        ));
        try {
          final scanned = await parserService.parseFile(event.filePaths[i]);
          if (scanned != null) scannedFiles.add(scanned);
        } catch (_) {
          failedCount++;
        }
      }

      stopwatch.stop();
      emit(ScanComplete(
        files: scannedFiles,
        elapsed: stopwatch.elapsed,
        failedCount: failedCount,
      ));
    } catch (e) {
      emit(ScanError(
        message: e.toString(),
        errorType: ScanErrorType.unknown,
      ));
    }
  }

  Future<void> _onCancel(CancelScanEvent event, Emitter<ScanState> emit) async {
    _isCancelled = true;
    emit(ScanInitial());
  }

  Future<void> _onClear(ClearScanEvent event, Emitter<ScanState> emit) async {
    emit(ScanInitial());
  }
}
