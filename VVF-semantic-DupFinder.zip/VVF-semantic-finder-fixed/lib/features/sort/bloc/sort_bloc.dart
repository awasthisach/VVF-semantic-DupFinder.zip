import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/models/scanned_file.dart';
import '../../../data/repositories/file_repository.dart';

// ══════════════════════════════════════════════
// EVENTS
// ══════════════════════════════════════════════
abstract class SortEvent extends Equatable {
  const SortEvent();
  @override
  List<Object?> get props => [];
}

class LoadFilesForSort extends SortEvent {
  final List<ScannedFile> files;
  const LoadFilesForSort(this.files);
  @override
  List<Object?> get props => [files];
}

class ChangeSortOrder extends SortEvent {
  final SortBy sortBy;
  final bool ascending;
  const ChangeSortOrder({required this.sortBy, this.ascending = true});
  @override
  List<Object?> get props => [sortBy, ascending];
}

class FilterByExtension extends SortEvent {
  final String? extension; // null = show all
  const FilterByExtension(this.extension);
  @override
  List<Object?> get props => [extension];
}

class SearchFiles extends SortEvent {
  final String query;
  const SearchFiles(this.query);
  @override
  List<Object?> get props => [query];
}

class DeleteFileEvent extends SortEvent {
  final ScannedFile file;
  const DeleteFileEvent(this.file);
  @override
  List<Object?> get props => [file];
}

// ══════════════════════════════════════════════
// STATES
// ══════════════════════════════════════════════
enum SortBy { name, dateModified, size, extension, source }

abstract class SortState extends Equatable {
  const SortState();
  @override
  List<Object?> get props => [];
}

class SortInitial extends SortState {}

class SortLoaded extends SortState {
  final List<ScannedFile> allFiles;
  final List<ScannedFile> displayFiles; // Filtered + sorted
  final SortBy sortBy;
  final bool ascending;
  final String? filterExtension;
  final String searchQuery;

  const SortLoaded({
    required this.allFiles,
    required this.displayFiles,
    this.sortBy = SortBy.dateModified,
    this.ascending = false,
    this.filterExtension,
    this.searchQuery = '',
  });

  // Stats
  int get totalFiles => allFiles.length;
  int get totalSizeBytes =>
      allFiles.fold(0, (sum, f) => sum + f.sizeBytes);
  Map<String, int> get extCounts {
    final counts = <String, int>{};
    for (final f in allFiles) {
      counts[f.extension] = (counts[f.extension] ?? 0) + 1;
    }
    return counts;
  }

  String get totalSizeFormatted {
    final bytes = totalSizeBytes;
    if (bytes > 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
    } else if (bytes > 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / 1024).toStringAsFixed(0)} KB';
  }

  @override
  List<Object?> get props =>
      [displayFiles, sortBy, ascending, filterExtension, searchQuery];
}

// ══════════════════════════════════════════════
// BLOC
// ══════════════════════════════════════════════
class SortBloc extends Bloc<SortEvent, SortState> {
  final FileRepository fileRepo;

  SortBloc({required this.fileRepo}) : super(SortInitial()) {
    on<LoadFilesForSort>(_onLoad);
    on<ChangeSortOrder>(_onChange);
    on<FilterByExtension>(_onFilter);
    on<SearchFiles>(_onSearch);
    on<DeleteFileEvent>(_onDelete);
  }

  void _onLoad(LoadFilesForSort event, Emitter<SortState> emit) {
    final sorted = _applySort(event.files, SortBy.dateModified, false);
    emit(SortLoaded(
      allFiles: event.files,
      displayFiles: sorted,
      sortBy: SortBy.dateModified,
      ascending: false,
    ));
  }

  void _onChange(ChangeSortOrder event, Emitter<SortState> emit) {
    if (state is! SortLoaded) return;
    final s = state as SortLoaded;
    final filtered = _applyFilter(
        s.allFiles, s.filterExtension, s.searchQuery);
    final sorted = _applySort(filtered, event.sortBy, event.ascending);
    emit(SortLoaded(
      allFiles: s.allFiles,
      displayFiles: sorted,
      sortBy: event.sortBy,
      ascending: event.ascending,
      filterExtension: s.filterExtension,
      searchQuery: s.searchQuery,
    ));
  }

  void _onFilter(FilterByExtension event, Emitter<SortState> emit) {
    if (state is! SortLoaded) return;
    final s = state as SortLoaded;
    final filtered = _applyFilter(s.allFiles, event.extension, s.searchQuery);
    final sorted = _applySort(filtered, s.sortBy, s.ascending);
    emit(SortLoaded(
      allFiles: s.allFiles,
      displayFiles: sorted,
      sortBy: s.sortBy,
      ascending: s.ascending,
      filterExtension: event.extension,
      searchQuery: s.searchQuery,
    ));
  }

  void _onSearch(SearchFiles event, Emitter<SortState> emit) {
    if (state is! SortLoaded) return;
    final s = state as SortLoaded;
    final filtered = _applyFilter(s.allFiles, s.filterExtension, event.query);
    final sorted = _applySort(filtered, s.sortBy, s.ascending);
    emit(SortLoaded(
      allFiles: s.allFiles,
      displayFiles: sorted,
      sortBy: s.sortBy,
      ascending: s.ascending,
      filterExtension: s.filterExtension,
      searchQuery: event.query,
    ));
  }

  Future<void> _onDelete(
      DeleteFileEvent event, Emitter<SortState> emit) async {
    if (state is! SortLoaded) return;
    final s = state as SortLoaded;
    await fileRepo.deleteFile(event.file.path);
    final updated = s.allFiles.where((f) => f.id != event.file.id).toList();
    final filtered = _applyFilter(updated, s.filterExtension, s.searchQuery);
    final sorted = _applySort(filtered, s.sortBy, s.ascending);
    emit(SortLoaded(
      allFiles: updated,
      displayFiles: sorted,
      sortBy: s.sortBy,
      ascending: s.ascending,
      filterExtension: s.filterExtension,
      searchQuery: s.searchQuery,
    ));
  }

  // ── Helpers ─────────────────────────────────────────
  List<ScannedFile> _applyFilter(
    List<ScannedFile> files,
    String? ext,
    String query,
  ) {
    var result = files;
    if (ext != null) {
      result = result.where((f) => f.extension == ext).toList();
    }
    if (query.isNotEmpty) {
      final q = query.toLowerCase();
      result =
          result.where((f) => f.name.toLowerCase().contains(q)).toList();
    }
    return result;
  }

  List<ScannedFile> _applySort(
    List<ScannedFile> files,
    SortBy by,
    bool ascending,
  ) {
    final sorted = List<ScannedFile>.from(files);
    sorted.sort((a, b) {
      int cmp;
      switch (by) {
        case SortBy.name:
          cmp = a.name.compareTo(b.name);
          break;
        case SortBy.dateModified:
          cmp = a.modifiedAt.compareTo(b.modifiedAt);
          break;
        case SortBy.size:
          cmp = a.sizeBytes.compareTo(b.sizeBytes);
          break;
        case SortBy.extension:
          cmp = a.extension.compareTo(b.extension);
          break;
        case SortBy.source:
          cmp = a.source.name.compareTo(b.source.name);
          break;
      }
      return ascending ? cmp : -cmp;
    });
    return sorted;
  }
}
