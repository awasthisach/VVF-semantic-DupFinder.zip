import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';

import '../../../data/models/scanned_file.dart';
import '../bloc/sort_bloc.dart';
import '../../file_detail/file_detail_screen.dart';

class SortScreen extends StatefulWidget {
  final List<ScannedFile> files;
  const SortScreen({super.key, required this.files});

  @override
  State<SortScreen> createState() => _SortScreenState();
}

class _SortScreenState extends State<SortScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<SortBloc>().add(LoadFilesForSort(widget.files));
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All files'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: TextField(
              controller: _searchCtrl,
              decoration: const InputDecoration(
                hintText: 'Search files...',
                prefixIcon: Icon(Icons.search),
                contentPadding: EdgeInsets.symmetric(vertical: 0),
              ),
              onChanged: (q) =>
                  context.read<SortBloc>().add(SearchFiles(q)),
            ),
          ),
        ),
      ),
      body: BlocBuilder<SortBloc, SortState>(
        builder: (context, state) {
          if (state is! SortLoaded) {
            return const Center(child: CircularProgressIndicator());
          }

          return Column(
            children: [
              // ── Filter chips + sort button ────────────────
              SizedBox(
                height: 48,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    // 'All' chip
                    Padding(
                      padding: const EdgeInsets.only(right: 6, top: 6),
                      child: FilterChip(
                        label: Text('All (${state.totalFiles})'),
                        selected: state.filterExtension == null,
                        onSelected: (_) => context
                            .read<SortBloc>()
                            .add(const FilterByExtension(null)),
                      ),
                    ),
                    // Per-extension chips
                    ...state.extCounts.entries.map((e) => Padding(
                          padding:
                              const EdgeInsets.only(right: 6, top: 6),
                          child: FilterChip(
                            label: Text(
                                '${e.key.toUpperCase()} (${e.value})'),
                            selected:
                                state.filterExtension == e.key,
                            onSelected: (_) => context
                                .read<SortBloc>()
                                .add(FilterByExtension(e.key)),
                          ),
                        )),
                    // Sort button
                    Padding(
                      padding: const EdgeInsets.only(left: 4, top: 6),
                      child: ActionChip(
                        avatar: const Icon(Icons.sort, size: 16),
                        label: Text(_sortLabel(state.sortBy)),
                        onPressed: () =>
                            _showSortMenu(context, state),
                      ),
                    ),
                  ],
                ),
              ),

              // ── Stats ─────────────────────────────────────
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 6),
                child: Row(
                  children: [
                    Text(
                      '${state.displayFiles.length} files',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const Spacer(),
                    Text(
                      'Total: ${state.totalSizeFormatted}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),

              const Divider(height: 1),

              // ── File List ────────────────────────────────
              Expanded(
                child: state.displayFiles.isEmpty
                    ? const Center(child: Text('No matching files'))
                    : ListView.builder(
                        itemCount: state.displayFiles.length,
                        itemBuilder: (ctx, i) {
                          final file = state.displayFiles[i];
                          return _FileListTile(
                            file: file,
                            onTap: () => Navigator.push(
                              ctx,
                              MaterialPageRoute(
                                builder: (_) =>
                                    FileDetailScreen(file: file),
                              ),
                            ),
                            onDelete: () => _confirmDelete(
                                context, state, file),
                          ).animate(
                            delay:
                                Duration(milliseconds: i * 30),
                          ).fadeIn();
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _showSortMenu(BuildContext ctx, SortLoaded state) {
    showModalBottomSheet(
      context: ctx,
      builder: (_) => BlocProvider.value(
        value: ctx.read<SortBloc>(),
        child: _SortMenu(current: state.sortBy, ascending: state.ascending),
      ),
    );
  }

  Future<void> _confirmDelete(
    BuildContext ctx,
    SortLoaded state,
    ScannedFile file,
  ) async {
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (d) => AlertDialog(
        title: const Text('Delete file?'),
        content: Text('"${file.name}" will be permanently deleted.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(d, false),
              child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(d, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true && ctx.mounted) {
      ctx.read<SortBloc>().add(DeleteFileEvent(file));
    }
  }

  String _sortLabel(SortBy by) {
    switch (by) {
      case SortBy.name:
        return 'Name';
      case SortBy.dateModified:
        return 'Date';
      case SortBy.size:
        return 'Size';
      case SortBy.extension:
        return 'Type';
      case SortBy.source:
        return 'Source';
    }
  }
}

// ── File List Tile ────────────────────────────────────────
class _FileListTile extends StatelessWidget {
  final ScannedFile file;
  final VoidCallback onDelete;
  final VoidCallback? onTap;
  const _FileListTile({required this.file, required this.onDelete, this.onTap});

  @override
  Widget build(BuildContext context) {
    final dateStr =
        DateFormat('dd MMM yyyy').format(file.modifiedAt);

    return ListTile(
      onTap: onTap,
      leading: _ExtIcon(ext: file.extension),
      title: Text(
        file.name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '$dateStr · ${file.sizeFormatted} · ${file.source.name}',
        style: Theme.of(context).textTheme.bodySmall,
      ),
      trailing: PopupMenuButton<String>(
        icon: const Icon(Icons.more_vert, size: 18),
        itemBuilder: (_) => [
          const PopupMenuItem(value: 'delete', child: Text('Delete')),
        ],
        onSelected: (v) {
          if (v == 'delete') onDelete();
        },
      ),
    );
  }
}

// ── Extension Icon ────────────────────────────────────────
class _ExtIcon extends StatelessWidget {
  final String ext;
  const _ExtIcon({required this.ext});

  @override
  Widget build(BuildContext context) {
    Color c;
    IconData ic;
    switch (ext.toLowerCase()) {
      case 'pdf':
        c = Colors.red;
        ic = Icons.picture_as_pdf_outlined;
        break;
      case 'docx':
      case 'doc':
        c = Colors.blue;
        ic = Icons.description_outlined;
        break;
      case 'txt':
      case 'md':
        c = Colors.teal;
        ic = Icons.article_outlined;
        break;
      case 'jpg':
      case 'jpeg':
      case 'png':
        c = Colors.orange;
        ic = Icons.image_outlined;
        break;
      default:
        c = Colors.grey;
        ic = Icons.insert_drive_file_outlined;
    }

    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: c.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(ic, color: c, size: 22),
    );
  }
}

// ── Sort Menu Sheet ───────────────────────────────────────
class _SortMenu extends StatelessWidget {
  final SortBy current;
  final bool ascending;
  const _SortMenu({required this.current, required this.ascending});

  @override
  Widget build(BuildContext context) {
    final options = [
      (SortBy.dateModified, Icons.calendar_today_outlined, 'Date modified'),
      (SortBy.name, Icons.sort_by_alpha, 'Name'),
      (SortBy.size, Icons.data_usage_outlined, 'File size'),
      (SortBy.extension, Icons.category_outlined, 'Type'),
      (SortBy.source, Icons.cloud_outlined, 'Source'),
    ];

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 8),
          child: Text('Sort by',
              style: Theme.of(context).textTheme.titleMedium),
        ),
        ...options.map((opt) {
          final (by, icon, label) = opt;
          final selected = current == by;
          return ListTile(
            leading: Icon(icon,
                color: selected
                    ? Theme.of(context).colorScheme.primary
                    : null),
            title: Text(label),
            trailing: selected
                ? Icon(
                    ascending
                        ? Icons.arrow_upward
                        : Icons.arrow_downward,
                    size: 18,
                    color: Theme.of(context).colorScheme.primary,
                  )
                : null,
            selected: selected,
            onTap: () {
              final asc = selected ? !ascending : false;
              context
                  .read<SortBloc>()
                  .add(ChangeSortOrder(sortBy: by, ascending: asc));
              Navigator.pop(context);
            },
          );
        }),
        const SizedBox(height: 12),
      ],
    );
  }
}
