import 'dart:convert';
import 'dart:typed_data';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:googleapis_auth/googleapis_auth.dart';
import 'package:http/http.dart' as http;
import 'package:logger/logger.dart';

/// Google Drive integration with OAuth 2.0 + Incremental Authorization.
/// Per the roadmap: request permissions ONLY when needed, not at install.
class GoogleDriveService {
  static const List<String> _baseScopes = [
    'email',
    'profile',
  ];

  // Drive scope requested only when user tries to scan Drive
  static const String _driveScope =
      'https://www.googleapis.com/auth/drive.readonly';

  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: _baseScopes, // Start minimal — no Drive scope yet
  );

  final Logger _log = Logger();
  drive.DriveApi? _driveApi;
  bool _hasDriveAccess = false;

  bool get isSignedIn => _googleSignIn.currentUser != null;
  bool get hasDriveAccess => _hasDriveAccess;
  String? get currentUserEmail => _googleSignIn.currentUser?.email;

  // ── Sign In ────────────────────────────────────────────
  Future<GoogleSignInAccount?> signIn() async {
    try {
      final account = await _googleSignIn.signIn();
      _log.i('Signed in: ${account?.email}');
      return account;
    } catch (e) {
      _log.e('Sign-in failed: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    await _googleSignIn.signOut();
    _driveApi = null;
    _hasDriveAccess = false;
  }

  // ── Incremental Auth: Request Drive scope when needed ──
  /// Called when user taps "Scan Google Drive" — not at app launch.
  Future<bool> requestDriveAccess() async {
    try {
      final account = await _googleSignIn.requestScopes([_driveScope]);
      if (account) {
        await _initializeDriveApi();
        _hasDriveAccess = true;
        _log.i('Drive access granted');
      }
      return account;
    } catch (e) {
      _log.e('Drive scope request failed: $e');
      return false;
    }
  }

  Future<void> _initializeDriveApi() async {
    final account = _googleSignIn.currentUser;
    if (account == null) throw StateError('Not signed in');

    final auth = await account.authHeaders;
    final client = _AuthenticatedClient(auth);
    _driveApi = drive.DriveApi(client);
  }

  // ── List Files ─────────────────────────────────────────
  /// Lists all documents in Drive (PDF, DOCX, Google Docs)
  Future<List<DriveFileInfo>> listDocuments({
    String? folderId,
    int maxFiles = 100,
  }) async {
    _assertDriveReady();

    final query = folderId != null
        ? "(mimeType='application/vnd.google-apps.document' or mimeType='application/pdf' or mimeType='application/vnd.openxmlformats-officedocument.wordprocessingml.document') and '$folderId' in parents"
        : "mimeType='application/vnd.google-apps.document' or mimeType='application/pdf' or mimeType='application/vnd.openxmlformats-officedocument.wordprocessingml.document'";

    final result = await _driveApi!.files.list(
      q: query,
      pageSize: maxFiles,
      $fields: 'files(id, name, mimeType, size, modifiedTime, md5Checksum)',
    );

    return (result.files ?? []).map((f) => DriveFileInfo.fromDrive(f)).toList();
  }

  // ── Export File Content ────────────────────────────────
  /// Exports a Google Doc as plain text (max 10 MB per API limit)
  Future<String?> exportAsText(String fileId, String mimeType) async {
    _assertDriveReady();

    try {
      if (mimeType == 'application/vnd.google-apps.document') {
        // Google Docs native format → export as plain text
        final media = await _driveApi!.files.export(
          fileId,
          'text/plain',
          downloadOptions: drive.DownloadOptions.fullMedia,
        );
        return await _mediaToString(media as drive.Media);
      } else {
        // PDF/DOCX → download binary (handled by DocParserService)
        return null; // Returns null — caller uses downloadBinary()
      }
    } catch (e) {
      _log.e('Export failed for $fileId: $e');
      return null;
    }
  }

  /// Downloads binary file (PDF, DOCX) for local parsing
  Future<Uint8List?> downloadBinary(String fileId) async {
    _assertDriveReady();

    try {
      final media = await _driveApi!.files.get(
        fileId,
        downloadOptions: drive.DownloadOptions.fullMedia,
      ) as drive.Media;

      final bytes = <int>[];
      const maxSizeBytes = 50 * 1024 * 1024; // 50 MB limit
      
      await for (final chunk in media.stream) {
        bytes.addAll(chunk);
        if (bytes.length > maxSizeBytes) {
          _log.w('File $fileId exceeds size limit — truncating');
          break;
        }
      }
      
      if (bytes.isEmpty) {
        _log.w('Downloaded file is empty: $fileId');
        return null;
      }
      
      return Uint8List.fromList(bytes);
    } catch (e) {
      _log.e('Download failed for $fileId: $e');
      return null;
    }
  }

  // ── Helpers ────────────────────────────────────────────
  Future<String> _mediaToString(drive.Media media) async {
    final buffer = StringBuffer();
    await for (final chunk in media.stream) {
      buffer.write(utf8.decode(chunk, allowMalformed: true));
    }
    return buffer.toString();
  }

  void _assertDriveReady() {
    if (_driveApi == null || !_hasDriveAccess) {
      throw StateError(
          'Drive API not initialized. Call requestDriveAccess() first.');
    }
  }
}

// ── Authenticated HTTP Client ──────────────────────────
class _AuthenticatedClient extends http.BaseClient {
  final Map<String, String> _headers;
  final http.Client _inner = http.Client();

  _AuthenticatedClient(this._headers);

  @override
  Future<http.StreamedResponse> send(http.BaseRequest request) {
    request.headers.addAll(_headers);
    return _inner.send(request);
  }
}

// ── Drive File Info ────────────────────────────────────
class DriveFileInfo {
  final String id;
  final String name;
  final String mimeType;
  final int? sizeBytes;
  final DateTime? modifiedTime;
  final String? md5Checksum;

  const DriveFileInfo({
    required this.id,
    required this.name,
    required this.mimeType,
    this.sizeBytes,
    this.modifiedTime,
    this.md5Checksum,
  });

  factory DriveFileInfo.fromDrive(drive.File f) {
    return DriveFileInfo(
      id: f.id ?? '',
      name: f.name ?? 'Unnamed',
      mimeType: f.mimeType ?? '',
      sizeBytes: int.tryParse(f.size ?? ''),
      modifiedTime: f.modifiedTime,
      md5Checksum: f.md5Checksum,
    );
  }

  bool get isGoogleDoc =>
      mimeType == 'application/vnd.google-apps.document';
  bool get isPdf => mimeType == 'application/pdf';
  bool get isDocx => mimeType ==
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
}
