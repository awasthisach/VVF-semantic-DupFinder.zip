import 'dart:math' as math;
import 'dart:typed_data';
import 'package:logger/logger.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:flutter/services.dart';

/// On-device embedding service using EmbeddingGemma 3 (300M).
/// Documents never leave the device — critical for enterprise privacy.
class EmbeddingService {
  static const String _modelPath = 'assets/models/embedding_gemma_300m.tflite';
  static const int _embeddingDim = 768;
  static const int _maxTokens = 512;

  Interpreter? _interpreter;
  final Logger _log = Logger();
  bool _isReady = false;

  bool get isReady => _isReady;

  // ── Initialization ─────────────────────────────────────
  Future<void> initialize() async {
    try {
      final options = InterpreterOptions()
        ..threads = 4
        ..useNnApiForAndroid = true; // Use Android Neural Networks API

      _interpreter = await Interpreter.fromAsset(
        _modelPath,
        options: options,
      );
      _isReady = true;
      _log.i('EmbeddingGemma model loaded successfully');
    } catch (e) {
      // Fallback: use simple TF-IDF if model not available during dev
      _log.w('Model load failed, using TF-IDF fallback: $e');
      _isReady = true; // Allow app to run in dev without model file
    }
  }

  // ── Generate Embedding Vector ──────────────────────────
  /// Converts text to a 768-dimensional semantic vector.
  Future<List<double>> embed(String text) async {
    if (!_isReady) throw StateError('EmbeddingService not initialized');

    // Truncate to model's max token limit
    final truncated = _truncateText(text, _maxTokens);

    if (_interpreter != null) {
      return _runModelInference(truncated);
    } else {
      // Dev fallback: TF-IDF style sparse vector
      return _tfidfFallbackEmbed(truncated);
    }
  }

  /// Runs TFLite model inference to get embedding vector.
  Future<List<double>> _runModelInference(String text) async {
    final inputTensor = _tokenize(text);
    final outputBuffer = List.filled(_embeddingDim, 0.0).reshape([1, _embeddingDim]);

    _interpreter!.run(inputTensor, outputBuffer);

    final rawVector = (outputBuffer[0] as List).cast<double>();
    return _l2Normalize(rawVector); // Normalize for cosine similarity
  }

  // ── Cosine Similarity ──────────────────────────────────
  /// Computes cosine similarity between two normalized vectors.
  /// Returns value between 0 (unrelated) and 1 (identical).
  double cosineSimilarity(List<double> vecA, List<double> vecB) {
    assert(vecA.length == vecB.length, 'Vectors must have same dimension');

    double dotProduct = 0.0;
    double normA = 0.0;
    double normB = 0.0;

    for (int i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }

    final denominator = math.sqrt(normA) * math.sqrt(normB);
    if (denominator == 0) return 0.0;

    return dotProduct / denominator;
  }

  // ── Batch Duplicate Detection ──────────────────────────
  /// Finds all duplicate pairs above the similarity threshold.
  /// 2026 recommended threshold: 0.85–0.90 for business docs.
  Future<List<DuplicatePair>> findDuplicates(
    List<DocumentEmbedding> documents, {
    double threshold = 0.87,
  }) async {
    final duplicates = <DuplicatePair>[];

    // O(n²) comparison — for large sets, use FAISS ANN search
    for (int i = 0; i < documents.length; i++) {
      for (int j = i + 1; j < documents.length; j++) {
        final similarity = cosineSimilarity(
          documents[i].vector,
          documents[j].vector,
        );

        if (similarity >= threshold) {
          duplicates.add(DuplicatePair(
            docA: documents[i],
            docB: documents[j],
            similarity: similarity,
          ));
        }
      }
    }

    // Sort by similarity (highest first)
    duplicates.sort((a, b) => b.similarity.compareTo(a.similarity));
    return duplicates;
  }

  // ── Helpers ────────────────────────────────────────────
  List<double> _l2Normalize(List<double> vector) {
    final norm = math.sqrt(vector.fold(0.0, (sum, v) => sum + v * v));
    if (norm == 0) return vector;
    return vector.map((v) => v / norm).toList();
  }

  String _truncateText(String text, int maxTokens) {
    // Rough estimate: 1 token ≈ 4 characters
    final maxChars = maxTokens * 4;
    return text.length > maxChars ? text.substring(0, maxChars) : text;
  }

  List<List<int>> _tokenize(String text) {
    // Simplified tokenization — replace with SentencePiece in production
    final bytes = text.codeUnits.take(_maxTokens).toList();
    while (bytes.length < _maxTokens) bytes.add(0); // Pad
    return [bytes];
  }

  /// Dev fallback: simple bag-of-words vector (when model not loaded)
  List<double> _tfidfFallbackEmbed(String text) {
    final words = text.toLowerCase().split(RegExp(r'\W+'));
    final vector = List<double>.filled(_embeddingDim, 0.0);
    for (final word in words) {
      if (word.isEmpty) continue;
      final idx = word.hashCode.abs() % _embeddingDim;
      vector[idx] += 1.0;
    }
    return _l2Normalize(vector);
  }

  void dispose() {
    _interpreter?.close();
  }
}

// ── Data Models ─────────────────────────────────────────
class DocumentEmbedding {
  final String fileId;
  final String fileName;
  final String filePath;
  final List<double> vector;
  final DateTime scannedAt;

  const DocumentEmbedding({
    required this.fileId,
    required this.fileName,
    required this.filePath,
    required this.vector,
    required this.scannedAt,
  });
}

class DuplicatePair {
  final DocumentEmbedding docA;
  final DocumentEmbedding docB;
  final double similarity;

  const DuplicatePair({
    required this.docA,
    required this.docB,
    required this.similarity,
  });

  /// Similarity percentage for UI display
  String get similarityPercent => '${(similarity * 100).toStringAsFixed(1)}%';

  DuplicateCategory get category {
    if (similarity >= 0.98) return DuplicateCategory.exactCopy;
    if (similarity >= 0.90) return DuplicateCategory.nearDuplicate;
    return DuplicateCategory.similarContent;
  }
}

enum DuplicateCategory {
  exactCopy,      // 0.98–1.00 → same doc, different name/location
  nearDuplicate,  // 0.90–0.97 → minor edits, reformatting
  similarContent, // 0.85–0.89 → rewritten, different draft
}
