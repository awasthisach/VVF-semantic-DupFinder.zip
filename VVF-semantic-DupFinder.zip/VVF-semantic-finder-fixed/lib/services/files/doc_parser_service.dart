import 'dart:io';
import 'dart:typed_data';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import 'package:docx_to_text/docx_to_text.dart';
import 'package:logger/logger.dart';
import 'package:path/path.dart' as p;
import 'package:crypto/crypto.dart';
import 'dart:convert';

import '../../data/models/scanned_file.dart';

/// Document Extraction Pipeline — converts binary files to plain text
/// for NLP processing. Supports PDF, DOCX, TXT, and images (via OCR).
class DocParserService {
  final Logger _log = Logger();

  // ── Main Parser Entry Point ────────────────────────────
  Future<ScannedFile?> parseFile(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) return null;

    final ext = p.extension(filePath).toLowerCase().replaceAll('.', '');
    final bytes = await file.readAsBytes();
    final hash = _md5Hash(bytes);

    try {
      final text = await _extractText(filePath, ext, bytes);
      if (text == null || text.trim().isEmpty) return null;

      final stat = await file.stat();

      return ScannedFile(
        id: hash, // MD5 as unique ID (not for duplicate detection!)
        name: p.basename(filePath),
        path: filePath,
        extension: ext,
        sizeBytes: stat.size,
        modifiedAt: stat.modified,
        scannedAt: DateTime.now(),
        textContent: _sanitizeText(text),
        source: FileSource.localStorage,
      );
    } catch (e) {
      _log.e('Parse failed for $filePath: $e');
      return null;
    }
  }

  // ── Text Extraction per Format ─────────────────────────
  Future<String?> _extractText(
    String path,
    String ext,
    Uint8List bytes,
  ) async {
    switch (ext) {
      case 'pdf':
        return _extractFromPdf(bytes);
      case 'docx':
      case 'doc':
        return _extractFromDocx(bytes);
      case 'txt':
      case 'md':
      case 'csv':
        return utf8.decode(bytes, allowMalformed: true);
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'webp':
        return _extractFromImage(path);
      default:
        _log.w('Unsupported extension: $ext');
        return null;
    }
  }

  // ── PDF Extraction (Syncfusion) ───────────────────────
  Future<String?> _extractFromPdf(Uint8List bytes) async {
    try {
      final document = PdfDocument(inputBytes: bytes);
      final extractor = PdfTextExtractor(document);

      final buffer = StringBuffer();

      for (int i = 0; i < document.pages.count; i++) {
        final pageText = extractor.extractText(startPageIndex: i, endPageIndex: i);
        if (pageText.isNotEmpty) {
          buffer.writeln(pageText);
        }
      }

      document.dispose();

      final text = buffer.toString().trim();

      // If PDF is scanned (image-only), text will be nearly empty
      if (text.length < 50) {
        _log.i('PDF appears to be scanned — falling back to OCR');
        // NOTE: For scanned PDFs, integrate Parsio or Nutrient AI SDK here
        return text.isEmpty ? null : text;
      }

      return text;
    } catch (e) {
      _log.e('PDF extraction failed: $e');
      return null;
    }
  }

  // ── DOCX Extraction ────────────────────────────────────
  Future<String?> _extractFromDocx(Uint8List bytes) async {
    try {
      final text = docxToText(bytes);
      return text.trim().isEmpty ? null : text;
    } catch (e) {
      _log.e('DOCX extraction failed: $e');
      return null;
    }
  }

  // ── Image OCR ─────────────────────────────────────────
  /// Uses on-device ML Kit (via Parsio API in production).
  /// For 2026: integrate Nutrient AI or Microsoft AI Builder for complex layouts.
  /// Currently returns null as OCR is not yet integrated.
  Future<String?> _extractFromImage(String imagePath) async {
    try {
      // TODO: Integrate ml_kit_text_recognition package
      // final inputImage = InputImage.fromFilePath(imagePath);
      // final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
      // final result = await recognizer.processImage(inputImage);
      // await recognizer.close();
      // return result.text;

      // Placeholder until ML Kit integrated
      _log.w('OCR not yet integrated for image: $imagePath. Skipping text extraction.');
      return null;
    } catch (e) {
      _log.e('OCR failed for $imagePath: $e');
      return null;
    }
  }

  // ── Text Sanitization ──────────────────────────────────
  /// Cleans up extracted text before sending to embedding model.
  String _sanitizeText(String raw) {
    return raw
        .replaceAll(RegExp(r'\s+'), ' ')          // Collapse whitespace
        .replaceAll(RegExp(r'[^\x20-\x7E\n]'), '') // Remove non-printable
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')    // Max 2 blank lines
        .trim();
  }

  String _md5Hash(Uint8List bytes) {
    return md5.convert(bytes).toString();
  }

  // ── Parse from Drive bytes ─────────────────────────────
  Future<ScannedFile?> parseFromBytes({
    required Uint8List bytes,
    required String fileName,
    required String fileId,
    required String mimeType,
    int sizeBytes = 0,
    DateTime? modifiedAt,
  }) async {
    final ext = _mimeToExt(mimeType);
    if (ext == null) return null;

    try {
      final text = await _extractText('', ext, bytes);
      if (text == null || text.trim().isEmpty) return null;

      return ScannedFile(
        id: fileId,
        name: fileName,
        path: 'drive://$fileId',
        extension: ext,
        sizeBytes: sizeBytes,
        modifiedAt: modifiedAt ?? DateTime.now(),
        scannedAt: DateTime.now(),
        textContent: _sanitizeText(text),
        source: FileSource.googleDrive,
      );
    } catch (e) {
      _log.e('Drive file parse failed for $fileName: $e');
      return null;
    }
  }

  /// Parse Google Docs exported as plain text (no binary parsing needed)
  ScannedFile parseFromText({
    required String text,
    required String fileName,
    required String fileId,
    int sizeBytes = 0,
    DateTime? modifiedAt,
  }) {
    return ScannedFile(
      id: fileId,
      name: fileName,
      path: 'drive://$fileId',
      extension: 'gdoc',
      sizeBytes: sizeBytes,
      modifiedAt: modifiedAt ?? DateTime.now(),
      scannedAt: DateTime.now(),
      textContent: _sanitizeText(text),
      source: FileSource.googleDrive,
    );
  }

  String? _mimeToExt(String mime) {
    const map = {
      'application/pdf': 'pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          'docx',
      'text/plain': 'txt',
      'image/jpeg': 'jpg',
      'image/png': 'png',
    };
    return map[mime];
  }
}
